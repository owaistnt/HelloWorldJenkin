package com.justadeveloper96.notificationdelegate

class DelegateNotFoundException(type: String) : Exception("No delegates found for this notification type: $type")
