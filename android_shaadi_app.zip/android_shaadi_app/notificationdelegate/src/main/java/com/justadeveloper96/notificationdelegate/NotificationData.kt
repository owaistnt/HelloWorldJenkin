package com.justadeveloper96.notificationdelegate

import android.os.Bundle
import android.util.Log
import com.google.gson.Gson
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken

/*data class NotificationData(var title: String?,
                            var message: String?,
                            val type: String,
                            val channelId: String,
                            val channelName: String,
                            val channelPriority: String,
                            val priority: Int?,
                            val iconImageUrl: String?,
                            val landingId: String?,
                            val landingAction: String?,
                            val style: String?,
                            val extras: Map<String, String>?,
                            val track:String?,
                            val pid:String?,
                            val tid:String?,
                            val url:String?,
                            @SerializedName("set_profiles_back") @Expose val profileBack:String?,
                            @SerializedName("evt_ref") @Expose  val evtRef:String?,
                            var actions: List<Action>?){
    lateinit var bundle: Bundle*/


data class NotificationData(val type: String) {
    lateinit var bundle: Bundle
    var title: String? = null
    var message: String? = null
    lateinit var channelId: String
    lateinit var channelName: String
    lateinit var channelPriority: String
    var priority: Int? = null
    var iconImageUrl: String? = null
    var landingId: String? = null
    var landingAction: String? = null
    var style: String? = null
    var extras: MutableMap<String, String>? = null
    var track: String? = null
    var pid: String? = null
    var tid: String? = null
    var url: String? = null

    var isExternalLanding: String? = null

    @SerializedName("set_profiles_back")
    @Expose
    var profileBack: String? = null
    @SerializedName("evt_ref")
    @Expose
    var evtRef: String? = null
    var actions: List<Action>? = null


    fun make() {
        bundle = Bundle()
        extras?.keys?.forEach { key ->

            if (key == "landing_panel") {
                extras?.get(key)?.let {
                    bundle.putString("landing_panel", it)
                }
            } else
                bundle.putString(key, extras!![key])
        }

        profileBack?.let {
            bundle.putString("set_profiles_back", it)
        }

        url?.let {
            bundle.putString("url", it)
        }
        actions?.forEach { action ->
            action.make()
        }
    }


    companion object {


        fun parser(data: Map<String, String>): NotificationData {
            Log.e("Notification Map", data.toString())
            return NotificationData(data["type"] ?: "DEF").apply {
                title = data["title"]
                message = data["message"]
                channelId = data["channel_id"] ?: "Shaadi"
                channelName = data["channel_name"] ?: "Shaadi"
                channelPriority = data["channel_priority"] ?: "high"
                iconImageUrl = data["img"]
                landingId = "mainActivity"
                landingAction = data["landing_action"]
                style = data["style"]
                isExternalLanding = data["is_external_url"]

                data["extras"]?.let {
                    val tokenType = object : TypeToken<Map<String, String>>() {}.type
                    extras = Gson().fromJson(it, tokenType)
                }
                track = data["track"]
                pid = data["pid"]
                tid = data["tid"]
                url = data["url"]
                profileBack = data["set_profiles_back"]
                evtRef = data["evt_ref"]


                data["actions"]?.let {
                    val tokenType = object : TypeToken<List<Action>>() {}.type
                    actions = Gson().fromJson(it, tokenType)
                }
            }
        }
    }
}

data class Action(val label: String, val extras: Map<String, String>?, val action: String?, val drawable: String) {
    lateinit var bundle: Bundle

    fun make() {
        bundle = Bundle()
        extras?.keys?.forEach {
            bundle.putString(it, extras[it])
        }
        bundle.putString("action",action)
    }
}
