package com.justadeveloper96.notificationdelegate

import android.content.Context


class DelegateManager(private val delegates: List<Delegate>){

    @Throws(NoSuchElementException::class)
    operator fun invoke(data: NotificationData, context: Context) {
        val type = data.type
        try {
            return getProperDelegate(type)(context,data)
        }catch (e:Exception){
            if (e is NoSuchElementException)
                throw DelegateNotFoundException(type)
        }
    }

    private fun getProperDelegate(type:String):Delegate{
        return delegates.first { it.canHandle(type) }
    }
}