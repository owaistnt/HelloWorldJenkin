package com.justadeveloper96.notificationdelegate

import android.content.Context

interface Delegate{

    fun canHandle(type:String):Boolean

    operator fun invoke(context: Context, data: NotificationData)
}