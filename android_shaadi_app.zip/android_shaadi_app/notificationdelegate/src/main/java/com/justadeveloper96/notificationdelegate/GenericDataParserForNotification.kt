/*
package com.justadeveloper96.notificationdelegate

import android.app.Notification
import android.content.Context
import android.support.v4.app.NotificationCompat
import javax.inject.Inject


class GenericDataParserForNotification(private val context: Context, data: Map<String, String>){

    init {
        setTitle(data)
        setMessage(data)
        setActions(data)
        setStyle(data)
        setImage(data)
    }

    private fun setChannel(context: Context) {

    }

    operator fun invoke(): NotificationCompat.Builder {

    }

    private fun setImage(data: Map<String, String>) {
    }

    private fun setMessage(data: Map<String, String>) {
    }

    private fun setTitle(data: Map<String, String>) {

    }

    private fun setActions(data: Map<String, String>) {

    }

    private fun setStyle(data:Map<String,String>){

    }

    */
/*val keyMapper = mapOf<String,(Map<String,String>)->Unit>(
       "importance" to ::setImportance
    )*//*

}
*/
