/*
package com.justadeveloper96.notificationdelegate

import android.arch.lifecycle.ViewModel
import android.arch.lifecycle.ViewModelProvider
import android.content.Context
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoMap
import dagger.multibindings.IntoSet

@Module
interface NotificationDelegateModule{

    @Binds
    @IntoSet
    abstract fun bindSearchViewModel(delegate:Delegate): Delegate

    @Binds
    abstract fun bindDelegateManager(factor: NotificationDelegateModule): DelegateManager

}
*/
