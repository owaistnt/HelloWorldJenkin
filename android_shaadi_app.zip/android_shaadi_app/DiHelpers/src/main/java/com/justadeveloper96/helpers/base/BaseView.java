package com.justadeveloper96.helpers.base;

public interface BaseView {
    public void onError();
}
