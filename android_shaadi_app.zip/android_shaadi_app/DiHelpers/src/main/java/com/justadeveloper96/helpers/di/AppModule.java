package com.justadeveloper96.helpers.di;

import android.app.Application;
import android.content.Context;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Created by harshith on 21/2/17.
 */
@Module
public class AppModule {
    public static final String DI_TAG = "DI_TAG";
    private Application mApp;

    public AppModule(Application application)
    {
        this.mApp=application;
    }

    @Provides
    @Singleton
    public Context provideContext() {
        return mApp.getApplicationContext();
    }

    @Provides
    @Singleton
    public Application provideAppInstance() {
        return mApp;
    }
}
