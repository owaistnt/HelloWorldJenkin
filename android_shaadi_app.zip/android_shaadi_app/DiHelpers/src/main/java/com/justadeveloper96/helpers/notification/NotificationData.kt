package com.justadeveloper96.helpers.notification

abstract class NotificationData {
    abstract val notificationId: Int
    abstract val title: String
    abstract val message: String
    abstract val type: String
    abstract val channelId: String
    abstract val channelName: String
    abstract val channelPriority: Int
    abstract val priority: Int
    abstract val iconImageUrl: String
    abstract val landingUrl: String
    abstract val style: String
    abstract val actions: String
}