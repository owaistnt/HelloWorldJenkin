/*
package com.justadeveloper96.helpers.notification

import android.support.v4.app.NotificationCompat
import android.support.v4.app.NotificationManagerCompat


class NotificationDataParse {


    companion object Parse {
        fun parseNotificationData(map: Map<String, String>): NotificationData {

            var title: String = ""
            var message: String = ""
            var type: String = ""
            var channelId: String = ""
            var channelName: String = ""
            var channelPriority: String? = null
            var iconImageUrl: String = ""
            var landingUrl: String = ""
            var channelImportance: Int
            var priority: Int
            var style:String=""
            var actions:String=""




            for ((key, value) in map) {

                when (key) {
                    "title" -> title = value
                    "message" -> message = value
                    "channel_id" -> channelId = value
                    "channel_name" -> channelName = value
                    "channel_priority" -> channelPriority = value
                    "icon_img_url" -> iconImageUrl = value
                    "landling_url" -> landingUrl = value
                    "style" -> style = value
                    "actions"-> actions=value
                }
            }

            when (channelPriority) {

                "high" -> {
                    channelImportance = NotificationManagerCompat.IMPORTANCE_HIGH
                    priority = NotificationCompat.PRIORITY_HIGH
                }
                "low" -> {
                    channelImportance = NotificationManagerCompat.IMPORTANCE_LOW
                    priority = NotificationCompat.PRIORITY_LOW
                }
                else -> {
                    channelImportance = NotificationManagerCompat.IMPORTANCE_DEFAULT
                    priority = NotificationCompat.PRIORITY_DEFAULT
                }
            }


            return NotificationData(System.currentTimeMillis().toInt(),
                    title, message, type,
                    channelId, channelName,
                    channelImportance, priority,
                    iconImageUrl, landingUrl,
                    style,actions)
        }
    }
}*/
