/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.base

import com.shaadi.shaadilite.data.network.IApiHelper
import com.shaadi.shaadilite.data.preferences.IPreferenceHelper

interface IBaseInteractor {

    val preferencesHelper: IPreferenceHelper
    val iApiHelper: IApiHelper

    fun setUserAsLoggedOut()

    fun setAccessToken(accessToken: String?)
}

