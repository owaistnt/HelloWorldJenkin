/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.data.network

import com.shaadi.shaadilite.core.usecases.EventUsecases
import com.shaadi.shaadilite.data.network.request.trackEvents.EventBody
import com.shaadi.shaadilite.data.network.response.trackEvents.ResponseData
import org.json.JSONObject

interface IApiHelper {

    fun trackEvent(headerMap: Map<String, String>,
                   memberlogin: String,
                   rawReqModel: EventBody, callback: EventUsecases.ICallback?)

    fun trackNotificationEvents(options:Map<String, String>): JSONObject?
}