/*
 * Copyright (c) 2017.  PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */

package com.shaadi.shaadilite.utils.builder

import android.content.Context

import com.shaadi.shaadilite.utils.Utils

import java.io.UnsupportedEncodingException
import java.net.URLEncoder
import java.util.HashMap

/**
 * Created by sanketb on 15/3/17.
 */

class NotificationTrackerBuilder(internal var context: Context) {
    internal var data: HashMap<String, String> = HashMap()

    val map: Map<String, String>
        get() {
            Utils.addDefaultParameter(context, data)
            return data
        }

    fun build(): Map<String, String> {
        return map
    }

    fun setType(sendtype: String?): NotificationTrackerBuilder {
        data["type"] = sendtype ?:""
        return this
    }

    fun setTidNotNull(sendTid: String?): NotificationTrackerBuilder {
        if (sendTid != null)
            data["tid"] = sendTid
        return this
    }

    fun setProfileidNotNull(sendprofileid: String?): NotificationTrackerBuilder {
        var truncatedPid: String
        if (sendprofileid != null) {
            truncatedPid = Utils.getLastString(sendprofileid, 220)
            try {
                truncatedPid = URLEncoder.encode(truncatedPid, "UTF-8")
                data["profileid"] = truncatedPid
            } catch (e: UnsupportedEncodingException) {
                e.printStackTrace()
            }

        }
        return this
    }

    fun setState(sendstate: String): NotificationTrackerBuilder {
        data["state"] = sendstate
        return this
    }
}
