/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.main.presenter

import android.net.Uri
import com.shaadi.shaadilite.contants.ApiConstants

class WebViewUrlHelper {
    val OPEN_PANEL = "open_panel"
    val PANEL_SIGN_UP = "sign_up"

    fun isExternalLinkUrl(url: String): Boolean {
        if (url.contains("whatsapp") || url.contains("mailto:")
                || url.startsWith("tel:") || url.startsWith("sms:")
                || url.startsWith("smsto:") || "mms:".startsWith(url))
            return true
        return false
    }

    fun isSignInScreenUrl(url: String): Boolean {
        return ApiConstants.NATIVE_FAKE_URL == url
    }

    fun isSignUpScreenUrl(url: String): Boolean {
        if (url.contains(ApiConstants.NATIVE_FAKE_URL)) {
            val uri = Uri.parse(url)
            val panel = uri.getQueryParameter(OPEN_PANEL)  //will return "V-Maths-Addition "
            return PANEL_SIGN_UP == panel
        }
        return false
    }

    interface Callback {
        fun loadExternalUrl()
        fun loadUrl()
        fun loadUrl(url:String)
    }
}