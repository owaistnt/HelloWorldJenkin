/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.base


import com.shaadi.shaadilite.data.network.IApiHelper
import com.shaadi.shaadilite.data.preferences.IPreferenceHelper

open class BaseInteractorImpl(private val mPreferencesHelper: IPreferenceHelper,
                              private val mIApiHelper: IApiHelper) : IBaseInteractor {
    override fun setAccessToken(accessToken: String?) {
    }

    override val iApiHelper: IApiHelper
        get() = mIApiHelper

    override val preferencesHelper: IPreferenceHelper
        get() = mPreferencesHelper


    override fun setUserAsLoggedOut() {}


}
