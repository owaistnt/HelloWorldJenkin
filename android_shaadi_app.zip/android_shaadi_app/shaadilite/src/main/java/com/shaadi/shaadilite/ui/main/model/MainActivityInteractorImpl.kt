/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.main.model

import com.shaadi.shaadilite.contants.ApiConstants
import com.shaadi.shaadilite.data.network.IApiHelper
import com.shaadi.shaadilite.data.preferences.IPreferenceHelper
import com.shaadi.shaadilite.ui.base.BaseInteractorImpl
import com.shaadi.shaadilite.utils.QueryHelper

class MainActivityInteractorImpl(mPreferencesHelper: IPreferenceHelper, mIApiHelper: IApiHelper) :
        BaseInteractorImpl(mPreferencesHelper, mIApiHelper), IMainActivityInteractor {

    override fun getFcmToken(): String? {
        return preferencesHelper.fcmToken
    }

    override fun clearCachedData() {
        preferencesHelper.notificationMd5Sum = null
    }

    override fun isLoggedInMember(): Boolean? {
        return preferencesHelper.isLoggedIn
    }

    override fun getMemberLoginId(): String? {
        return preferencesHelper.memberId
    }

    override fun isTokenChangedOrEmpty(userData: UserData): Boolean {
        return preferencesHelper.abcToken.isNullOrEmpty() || preferencesHelper.abcToken != userData.abc
    }

    override fun markUserLoggedInStatus(isLogged: Boolean) {
        preferencesHelper.isLoggedIn = isLogged
    }

    override fun saveUserData(userData: UserData) {
        preferencesHelper.memberId = userData.memberLogin
        preferencesHelper.abcToken = userData.abc
    }

    override fun loginApi(): String {
        return ApiConstants.LOGIN_URL + preferencesHelper.let { QueryHelper.WebCallDefaultQueryParams(it) }
    }

    override fun regApi(): String {
        return ApiConstants.REGISTRATION_URL + preferencesHelper.let { QueryHelper.WebCallDefaultQueryParams(it) }
    }

}