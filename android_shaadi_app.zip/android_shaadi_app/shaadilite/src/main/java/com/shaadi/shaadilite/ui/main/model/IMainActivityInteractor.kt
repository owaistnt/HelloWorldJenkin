/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.main.model

import com.shaadi.shaadilite.ui.base.IBaseInteractor
import org.json.JSONObject

interface IMainActivityInteractor : IBaseInteractor {

    fun saveUserData(userData: UserData)
    fun isTokenChangedOrEmpty(userData: UserData): Boolean
    fun markUserLoggedInStatus(isLogged: Boolean)
    fun getMemberLoginId(): String?
    fun getFcmToken(): String?
    fun clearCachedData()
    fun isLoggedInMember(): Boolean?
    fun loginApi(): String
    fun regApi(): String
}