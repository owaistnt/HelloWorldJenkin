/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.data.preferences


/**
 * Created by munnag on 20/12/17.
 */

interface IPreferenceHelper {

    var gaid: String?
    var fcmToken: String?
    var abcToken: String?

    var isLoggedIn:Boolean

    var memberId:String?

    var notificationMd5Sum:String?
}
