package com.shaadi.shaadilite.analytics

/**
Created by kiranb on 10/4/19
 */
import android.content.Context
import android.util.Log
import com.appsflyer.AppsFlyerLib
import org.json.JSONObject


object AppsFlyerAnalytics {

    fun trackEvent(eventName: String, eventType: JSONObject, context: Context) {
        sendToAppsflyer(getEventValues(eventType), eventName, context)
    }

    private fun sendToAppsflyer(eventsValues: Map<String, String>, event: String, context: Context) {
        Log.d("aps", "evet ${event} values :${eventsValues}")
        AppsFlyerLib.getInstance().trackEvent(context, event, eventsValues)

    }

    private fun getEventValues(eventType: JSONObject): HashMap<String, String> {
        val eventVal = HashMap<String, String>()
        val keys = eventType.keys()

        while (keys.hasNext()) {
            val key = keys.next() as String
            val value = eventType.getString(key)
            eventVal.put(key, value)

        }
        return eventVal
    }

}