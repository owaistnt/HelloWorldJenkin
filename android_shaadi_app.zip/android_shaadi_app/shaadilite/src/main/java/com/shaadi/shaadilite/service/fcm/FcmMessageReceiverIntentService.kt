/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.service.fcm

import android.os.Bundle
import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.shaadi.shaadilite.core.interactors.EventInteractorImpl
import com.shaadi.shaadilite.core.usecases.EventUsecases
import com.shaadi.shaadilite.core.usecases.TokenGenerated
import com.shaadi.shaadilite.data.network.IApiHelper
import com.shaadi.shaadilite.data.network.RetrofitApiHelperImpl
import com.shaadi.shaadilite.data.preferences.AppPreferenceHelper
import com.shaadi.shaadilite.service.notification.NotificationData
import com.shaadi.shaadilite.service.notification.NotificationDataParse
import com.shaadi.shaadilite.service.notification.NotificationUtil
import com.shaadi.shaadilite.utils.FirebaseTracking
import com.shaadi.shaadilite.utils.Utils
import com.shaadi.shaadilite.utils.builder.NotificationTrackerBuilder


/**
 * Created by munna on 18/1/17.
 */

class FcmMessageReceiverIntentService : FirebaseMessagingService() {

    /**
     * Called when message is received.
     *
     * @param remoteMessage Object representing the message received from Firebase Cloud Messaging.
     */
    // [START receive_message]
    override fun onMessageReceived(remoteMessage: RemoteMessage?) {
        // [START_EXCLUDE]
        // There are two types of messages data messages and notification messages. Data messages are handled
        // here in onMessageReceived whether the app is in the foreground or background. Data messages are the type
        // traditionally used with GCM. Notification messages are only received here in onMessageReceived when the app
        // is in the foreground. When the app is in the background an automatically generated notification is displayed.
        // When the user taps on the notification they are returned to the app. Messages containing both notification
        // and data payloads are treated as notification messages. The Firebase console always sends notification
        // messages. For more see: https://firebase.google.com/docs/cloud-messaging/concept-options
        // [END_EXCLUDE]

        // Not getting messages here? See why this may be: https://goo.gl/39bRNJ
        Log.d(TAG, "From: " + remoteMessage!!.from!!)

        // Check if message contains a data payload.
        if (remoteMessage.data.isNotEmpty()) {
            Log.d(TAG, "Message data payload: " + remoteMessage.data)

            //            if (/* Check if data needs to be processed by long running job */ true) {
            //                // For long-running tasks (10 seconds or more) use Firebase Job Dispatcher.
            //                scheduleJob();
            //            } else {
            //                // Handle message within 10 seconds
            //                handleNow(remoteMessage.getData());
            //            }

            handleNow(remoteMessage.data)

        }
    }
    // [END receive_message]


    // [START on_new_token]
    /**
     * Called if InstanceID token is updated. This may occur if the security of
     * the previous token had been compromised. Note that this is called when the InstanceID token
     * is initially generated so this is where you would retrieve the token.
     */
    override fun onNewToken(token: String) {
        Log.d(TAG, "Refreshed token: " + token)

        // If you want to send messages to this application instance or
        // manage this apps subscriptions on the server side, send the
        // Instance ID token to your app server.
        sendRegistrationToServer(token)
    }
    // [END on_new_token]

    /**
     * Schedule a job using FirebaseJobDispatcher.
     */
    private fun scheduleJob() {
        // [START dispatch_job]
        //        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(this));
        //        Job myJob = dispatcher.newJobBuilder()
        //                .setService(MyJobService.class)
        //                .setTag("my-job-tag")
        //                .build();
        //        dispatcher.schedule(myJob);
        // [END dispatch_job]
    }

    /**
     * Handle time allotted to BroadcastReceivers.
     * @param data
     */
    private fun handleNow(data: Map<String, String>) {
        Log.d(TAG, "Short lived task is done.")
        val notificationData = NotificationDataParse.parseNotificationData(data)

        val bundle = Bundle()
        bundle.putString("notificaton_type", notificationData.type)
        FirebaseTracking.trackEvent(FirebaseTracking.NOTIFICATION_DELIVERED, bundle)

        if (!AppPreferenceHelper.getInstance().memberId.isNullOrEmpty() && !AppPreferenceHelper.getInstance().abcToken.isNullOrEmpty())
            trackMessageDelivered(notificationData)
        NotificationUtil.generateNotification(this, notificationData)
    }

    private fun trackMessageDelivered(notificationData: NotificationData) {
        val mIApiHelper = RetrofitApiHelperImpl()
        val headerMap = HashMap<String, String>()
        val notificationTrackerBuilder = NotificationTrackerBuilder(this)
                .setType(notificationData.type)
                .setState("" + Utils.NOTIFICATION_DELIVERED)
                .setTidNotNull(notificationData.tid).build()
        headerMap.putAll(notificationTrackerBuilder)

        mIApiHelper.trackNotificationEvents(notificationTrackerBuilder)
    }

    /**
     * Persist token to third-party servers.
     *
     * Modify this method to associate the user's FCM InstanceID token with any server-side account
     * maintained by your application.
     *
     * @param token The new token.
     */
    private fun sendRegistrationToServer(token: String) {
        if (AppPreferenceHelper.getInstance().isLoggedIn) {
            val eventUsecases = EventUsecases(EventInteractorImpl(AppPreferenceHelper.getInstance(), RetrofitApiHelperImpl()))
            AppPreferenceHelper.getInstance().fcmToken = token
            eventUsecases.trackEvent(TokenGenerated(source = ""))
        }
    }

    companion object {


        private val TAG = "MyFirebaseMsgService"
    }


}
