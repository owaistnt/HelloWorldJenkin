package com.shaadi.shaadilite.service.notification

data class NotificationData(var notificationId: Int, var title: String,
                            var message: String,
                            var type: String,
                            var channelId: String,
                            var channelName: String,
                            var channelPriority: Int,
                            var priority: Int,
                            var iconImageUrl: String,
                            var landingUrl: String,
                            var style: String,
                            var actions: String,
                            var tid: String)