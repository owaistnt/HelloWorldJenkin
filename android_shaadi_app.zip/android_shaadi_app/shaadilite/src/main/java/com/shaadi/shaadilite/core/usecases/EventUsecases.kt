package com.shaadi.shaadilite.core.usecases

import com.shaadi.shaadilite.core.interactors.IEventInteractor
import com.shaadi.shaadilite.data.network.request.trackEvents.*
import com.shaadi.shaadilite.data.network.response.trackEvents.ResponseData
import java.util.*

class EventUsecases(val interactor: IEventInteractor) {

    fun trackEvent(eventTypes: EventTypes, callback: ICallback? = null) {
        with(getEventData(eventTypes)) {
            interactor.trackEventOnServer(this.headerMap, this.rawReqModel,callback)
            interactor.trackEventOnThirdParty(eventTypes)

//            if (callback != null) {
//                callback.onApiResponse(response)
//            }
        }
    }

    private fun getEventData(eventTypes: EventTypes): Result {
        when (eventTypes) {
            is TokenGenerated-> {
                val token = interactor.getFcmToken() ?: ""
                return Result(getHeaders(), getEventBodyData(eventTypes, token))
            }
            is TrackLogout, is TrackLogin  -> {
                return Result(getHeaders(), getEventBodyData(eventTypes))
            }
            is NotificationSettingChanged -> {
                return Result(getHeaders(), getEventBodyData(eventTypes, channel = eventTypes.channel, notificationSetting = eventTypes.notificationSetting))
            }
        }
    }

    private fun getEventBodyData(eventTypes: EventTypes, fcmToken: String? = null, channel: Map<String, ChannelInfo>? = null, notificationSetting: Boolean = true): EventBody {
        val eventDataMap = HashMap<String, Any>()
        eventDataMap[eventTypes.eventType] = getEventDetails(eventTypes, fcmToken, channel, notificationSetting)
        eventDataMap["type"] = arrayOf(eventTypes.eventType)

        return EventBody(eventDataMap)
    }

    private fun getEventDetails(eventTypes: EventTypes, fcmToken: String?, channel: Map<String, ChannelInfo>?, channelSetting: Boolean? = null): EventDetails {
        return EventDetails().apply {
            memberlogin = interactor.getMemberLogin()!!
            event_name = eventTypes.eventName
            event_info = getEventInfo(eventTypes, fcmToken, channel, channelSetting)
        }
    }

    private fun getEventInfo(eventTypes: EventTypes, fcmToken: String?, channel: Map<String, ChannelInfo>?, channelSetting: Boolean?): EventInfo {
        return EventInfo().apply {
            source = eventTypes.source
            device_id = interactor.getDeviceId()!!
            system_settings = channelSetting
            this.channel = channel
            this.device_token = fcmToken
        }
    }

    private fun getHeaders(): Map<String, String> {
        return HashMap()
    }

    data class Result(val headerMap: Map<String, String>, val rawReqModel: EventBody)

    interface ICallback {
        fun onApiResponse(response: ResponseData?)
    }
}
