/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.login

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.View
import com.shaadi.shaadilite.R
import com.shaadi.shaadilite.data.network.RetrofitApiHelperImpl
import com.shaadi.shaadilite.data.preferences.AppPreferenceHelper
import com.shaadi.shaadilite.ui.base.BaseActivity
import com.shaadi.shaadilite.ui.login.model.ILoginActivityInteractor
import com.shaadi.shaadilite.ui.login.model.LoginActivityInteractorImpl
import com.shaadi.shaadilite.ui.login.presenter.ILoginActivityPresenter
import com.shaadi.shaadilite.ui.login.presenter.LoginActivityPresenterImpl
import com.shaadi.shaadilite.ui.login.view.ILoginActivityView
import com.shaadi.shaadilite.ui.main.MainActivity
import com.shaadi.shaadilite.utils.FirebaseTracking
import com.shaadi.shaadilite.utils.WebviewCookieHandler
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : BaseActivity(), View.OnClickListener, ILoginActivityView {

    val mCookieHelper: WebviewCookieHandler by lazy {
        WebviewCookieHandler()
    }

    lateinit var mPresenter: ILoginActivityPresenter<ILoginActivityView, ILoginActivityInteractor>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        mCookieHelper.clearCookies(object:WebviewCookieHandler.Callback{
            override fun cleared(cleared: Boolean?) {
                setUp()
            }
        })
    }



    override fun setUp() {
        mCookieHelper.acceptCookies()
        btnSignIn.setOnClickListener(this)
        btnRegisterFree.setOnClickListener(this)
        mPresenter = LoginActivityPresenterImpl(LoginActivityInteractorImpl(AppPreferenceHelper.getInstance(), RetrofitApiHelperImpl()))
        mPresenter.onAttach(this)
        registerBroadCastForLoginStackClearing()
    }

    override fun onClick(v: View?) = when (v?.id) {
        R.id.btnSignIn -> mPresenter.onLoginButtonClick()
        R.id.btnRegisterFree -> mPresenter.onRegButtonClick()
        else -> {
        }
    }

    override fun openLoginScreen(landingUrl: String) {
        FirebaseTracking.trackEvent(FirebaseTracking.NATIVE_CLICK_SIGN_IN)

        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra(MainActivity.KEY_LANDING_URL, landingUrl)
        }
        startActivity(intent)
    }

    override fun openRegistrationScreen(loginUrl: String) {
        FirebaseTracking.trackEvent(FirebaseTracking.NATIVE_CLICK_REGISTRATION)
        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra(MainActivity.KEY_LANDING_URL, loginUrl)
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        mPresenter.onDetach()
        super.onDestroy()
        unregisterReceiver(closeActivtyReciever)
    }

    override fun setCookies(cookies: ArrayList<String>) {
        mCookieHelper.setCookies(cookies)
    }

    private fun registerBroadCastForLoginStackClearing() {
        val intentFilter = IntentFilter().apply {
            addAction("com.package.ACTION_LOGOUT")
        }

        registerReceiver(closeActivtyReciever, intentFilter)
    }

    private val closeActivtyReciever=object: BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            finish()
        }
    }

}

