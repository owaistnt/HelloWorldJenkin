/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.login.model

import com.shaadi.shaadilite.BuildConfig
import com.shaadi.shaadilite.contants.ApiConstants
import com.shaadi.shaadilite.contants.QueryKeyConstants
import com.shaadi.shaadilite.contants.QueryValueConstants
import com.shaadi.shaadilite.data.network.IApiHelper
import com.shaadi.shaadilite.data.preferences.IPreferenceHelper
import com.shaadi.shaadilite.ui.base.BaseInteractorImpl
import com.shaadi.shaadilite.utils.CookieBuilder
import com.shaadi.shaadilite.utils.QueryHelper

class LoginActivityInteractorImpl(mPreferencesHelper: IPreferenceHelper, mIApiHelper: IApiHelper) :
        BaseInteractorImpl(mPreferencesHelper, mIApiHelper), ILoginActivityInteractor {


    override fun getCookies(): ArrayList<String> {
        val cookieBuilder = CookieBuilder().apply {
            setCookie(CookieBuilder.LITEM, true)
            setCookie(CookieBuilder.SLITE, BuildConfig.SHAADI_LITE_APP_SLANGUAGE)

            //this check is to not set cookie value when the main shaadilite app is rendered
            if (!QueryValueConstants.MAIN_APP_SLANG.equals(QueryValueConstants.VALUE_APP_LANGUAGE))
                setCookie(QueryKeyConstants.KEY_APP_LANGUAGE, QueryValueConstants.VALUE_APP_LANGUAGE)
        }
        return cookieBuilder.build()
    }

    override fun loginApi(): String {
        return ApiConstants.LOGIN_URL + preferencesHelper.let { QueryHelper.WebCallDefaultQueryParams(it) }
    }

    override fun regApi(): String {
        return ApiConstants.REGISTRATION_URL + preferencesHelper.let { QueryHelper.WebCallDefaultQueryParams(it) }
    }
}