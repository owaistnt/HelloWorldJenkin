/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.utils

import java.io.UnsupportedEncodingException

class CookieBuilder {

    val cookieMap = HashMap<String, String>();
    val cookieBolMap = HashMap<String, Boolean>();

    companion object {
        const val LITEM = "litem"
        const val SLITE= "slite"
    }

    fun setCookie(key: String, value: String) {
        this.cookieMap[key] = value
    }

    fun setCookie(key: String, value: Boolean) {
        this.cookieBolMap[key] = value
    }

    private fun getKeyValue(): String {
        val stringBuilder = StringBuffer()

        for (keySet in cookieMap.entries) {
            val value = keySet.value
            try {
                stringBuilder.append(keySet.key)
                stringBuilder.append("=")
                stringBuilder.append(value)
                stringBuilder.append(";")
            } catch (e: UnsupportedEncodingException) {
                throw RuntimeException("This method requires UTF-8 encoding support", e)
            }

        }

        return stringBuilder.toString()

    }

    private fun getStringKeyValue(): ArrayList<String> {
        val stringList = ArrayList<String>()

        for (keySet in cookieMap.entries)
            stringList.add(keySet.key+"="+keySet.value+";")

        return stringList
    }

    private fun getBooleanKeyValue(): ArrayList<String> {
        val stringList = ArrayList<String>()

        for (keySet in cookieBolMap.entries)
            stringList.add(keySet.key + "=" + keySet.value + ";")

        return stringList
    }


    fun build(): ArrayList<String> {
        val stringList = ArrayList<String>()
        stringList.addAll(getStringKeyValue())
        stringList.addAll(getBooleanKeyValue())

        return stringList
    }
}