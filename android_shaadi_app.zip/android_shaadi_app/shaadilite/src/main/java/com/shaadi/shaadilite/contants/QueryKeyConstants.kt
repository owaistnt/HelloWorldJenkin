/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.contants

object QueryKeyConstants {
    //default query
    val KEY_REG_MOD="regmode"
    val KEY_OS="os"
    val KEY_DEVICE_ID="deviceid"
    val KEY_APP_VERSION="appver"
    val KEY_MANUFACTURER="manufacturer"
    val KEY_MODEL="model"
    val KEY_APP_LANGUAGE="slang"

    val KEY_ABC="abc"
    val KEY_ML="ml"
    val KEY_FORMAT="format"
    val KEY_APPLAUNCH="appLaunch"
}