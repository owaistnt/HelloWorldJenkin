package com.shaadi.shaadilite.data.network.retrofit_client

import com.shaadi.shaadilite.BuildConfig
import okhttp3.Interceptor
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit


interface RetroClientInterface {

    companion object {
        val soaInstance: retrofit2.Retrofit by lazy {
            val okClient = okhttp3.OkHttpClient.Builder()
            okClient.connectTimeout(2,TimeUnit.MINUTES)
            okClient.writeTimeout(2,TimeUnit.MINUTES)
            okClient.readTimeout(2,TimeUnit.MINUTES)

            if (BuildConfig.DEBUG) {
                val logging = HttpLoggingInterceptor()
                logging.level = HttpLoggingInterceptor.Level.BODY;
                okClient.addInterceptor(logging)
            }
            val retrofit = retrofit2.Retrofit.Builder()
                    .baseUrl(BuildConfig.SHAADI_SOA_URL)
                    .client(okClient.build())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()

            retrofit
        }
        val zendInstance: retrofit2.Retrofit by lazy {
            val okClient = okhttp3.OkHttpClient.Builder()
            okClient.connectTimeout(2,TimeUnit.MINUTES)
            okClient.writeTimeout(2,TimeUnit.MINUTES)
            okClient.readTimeout(2,TimeUnit.MINUTES)

            if (BuildConfig.DEBUG) {
                val logging = HttpLoggingInterceptor()
                logging.level = HttpLoggingInterceptor.Level.BODY;
                okClient.addInterceptor(logging)
            }
            val retrofit = retrofit2.Retrofit.Builder()
                    .baseUrl(BuildConfig.SHAADI_LITE_URL+"/native-apps2/")
                    .client(okClient.build())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()

            retrofit
        }

    }

}
