package com.shaadi.shaadilite.service.notification.notificationSettings

import android.app.IntentService
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.support.v4.app.NotificationManagerCompat
import android.util.Log
import com.google.gson.Gson
import com.shaadi.shaadilite.core.interactors.EventInteractorImpl
import com.shaadi.shaadilite.core.usecases.EventUsecases
import com.shaadi.shaadilite.core.usecases.NotificationSettingChanged
import com.shaadi.shaadilite.data.network.RetrofitApiHelperImpl
import com.shaadi.shaadilite.data.network.request.trackEvents.ChannelInfo
import com.shaadi.shaadilite.data.network.response.trackEvents.Data
import com.shaadi.shaadilite.data.network.response.trackEvents.ResponseData
import com.shaadi.shaadilite.data.preferences.AppPreferenceHelper
import com.shaadi.shaadilite.utils.Utils
import org.json.JSONObject

class NotificationStateChangeIntentService : IntentService("NotificationStateChangeIntentService") {
    private val notificationManager: NotificationManager by lazy { getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager }

    private val eventUsecases: EventUsecases by lazy {
        EventUsecases(EventInteractorImpl(AppPreferenceHelper.getInstance(), RetrofitApiHelperImpl()))
    }

    override fun onHandleIntent(intent: Intent?) {
        val channelMap = getChannelWithSettings();
        val settingData = getSystemNotificationSetting()
        val eventType = NotificationSettingChanged(source = "", channel = channelMap, notificationSetting = getSystemNotificationSetting())

        val currentNotificationSettingsMd5 = getChangingDataMd5Sum(channelMap, settingData)

        Log.d("md5", " md5 ${currentNotificationSettingsMd5}")
        if (isNotificationSettingChanged(currentNotificationSettingsMd5)) {
            eventUsecases.trackEvent(eventType,
                    object : EventUsecases.ICallback {
                        override fun onApiResponse(response: ResponseData?) {
                            response?.data?.let { it ->
                                if (it.values.first().action_status) {
                                    AppPreferenceHelper.getInstance().notificationMd5Sum = currentNotificationSettingsMd5
                                }
                            }
                        }
                    })
        }
    }

    private fun getChangingDataMd5Sum(channelsMap: Map<String, ChannelInfo>, settingData: Boolean): String? {
        val jsonObject = JSONObject()
        val channelJson = Gson().toJson(channelsMap)

        jsonObject.put("channelInfo", channelJson)
        jsonObject.put("NotificaitonSetting", settingData)

        return Utils.generateMD5Hash(jsonObject)
    }

    private fun isNotificationSettingChanged(currentNotificationSettingsMd5: String?): Boolean {

        val lastNotificationSettingsHashMd5 = AppPreferenceHelper.getInstance().notificationMd5Sum

        return lastNotificationSettingsHashMd5.isNullOrEmpty()
                || !lastNotificationSettingsHashMd5.equals(currentNotificationSettingsMd5)
    }

    fun getChannelWithSettings(): Map<String, ChannelInfo> {
        val channelList = HashMap<String, ChannelInfo>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.notificationChannels.iterator().forEach {
                val channelInfo = ChannelInfo()
                channelInfo.priority = PRIORITY.values()[it.importance].name
                channelList[it.id] = channelInfo
            }
        }
        return channelList
    }

    private fun getSystemNotificationSetting(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            notificationManager.areNotificationsEnabled()
        } else {
            NotificationManagerCompat.from(applicationContext).areNotificationsEnabled()
        }
    }

    enum class PRIORITY {
        IMPORTANCE_NONE,
        IMPORTANCE_MIN, IMPORTANCE_LOW, IMPORTANCE_DEFAULT, IMPORTANCE_HIGH
    }
}