package com.shaadi.shaadilite.data.network.response;

import com.google.gson.annotations.SerializedName;

public class Error {

    @SerializedName("message")
    private String message;

    @SerializedName("status")
    private String status;

    @SerializedName("group")
    private String group;

    @SerializedName("type")
    private String type;

    @SerializedName("qs")
    private String qs;

    @SerializedName("datetime")
    private String datetime;

    @SerializedName("url")
    private String url;

    @SerializedName("message_shortcode")
    private String messageShortcode;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getQs() {
        return qs;
    }

    public void setQs(String qs) {
        this.qs = qs;
    }

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMessageShortcode() {
        return messageShortcode;
    }

    public void setMessageShortcode(String messageShortcode) {
        this.messageShortcode = messageShortcode;
    }
}