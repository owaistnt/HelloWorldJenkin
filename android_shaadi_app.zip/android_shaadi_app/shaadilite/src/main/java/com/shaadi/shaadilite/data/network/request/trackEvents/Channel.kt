package com.shaadi.shaadilite.data.network.request.trackEvents

data class Channel(
        var channelInfoList: Map<String, ChannelInfo>
)