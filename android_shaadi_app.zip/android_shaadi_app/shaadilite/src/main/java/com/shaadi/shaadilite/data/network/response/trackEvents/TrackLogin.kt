package com.shaadi.shaadilite.data.network.response.trackEvents

data class TrackLogin(
        val action_status: Boolean
)