package com.shaadi.shaadilite.data.network.request.trackEvents

data class EventBody (
      val data:Map<String,Any>
)