/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.main.presenter

import com.shaadi.shaadilite.core.usecases.EventTypes
import com.shaadi.shaadilite.ui.base.IBasePresenter
import com.shaadi.shaadilite.ui.main.model.IMainActivityInteractor
import com.shaadi.shaadilite.ui.main.model.UserData
import com.shaadi.shaadilite.ui.main.view.IMainActivityView

interface IMainActivityPresenter<V : IMainActivityView, I : IMainActivityInteractor> : IBasePresenter<V, I> {

    fun handleWebUrl(url: String, callback: WebViewUrlHelper.Callback)
    fun onUserLoggedIn(userData: UserData)
    fun onUserLoggedOut()
    fun isLoggedInMember(): Boolean
    fun processPageLoading(uri: String?, isDeepLink: Boolean, deepLinkUri: String? = null)

}