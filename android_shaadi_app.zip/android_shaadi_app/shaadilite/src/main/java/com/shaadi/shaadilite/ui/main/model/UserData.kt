package com.shaadi.shaadilite.ui.main.model

data class UserData(
        val memberLogin: String?,
        val abc: String?){

    val isValid=!memberLogin.isNullOrEmpty() && !abc.isNullOrEmpty()
}

