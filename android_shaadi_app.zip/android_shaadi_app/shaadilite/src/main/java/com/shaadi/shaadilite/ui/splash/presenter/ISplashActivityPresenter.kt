/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.splash.presenter

import com.shaadi.shaadilite.ui.base.IBasePresenter
import com.shaadi.shaadilite.ui.main.model.UserData
import com.shaadi.shaadilite.ui.splash.SplashScreenActivity
import com.shaadi.shaadilite.ui.splash.model.ISplashActivityInteractor
import com.shaadi.shaadilite.ui.splash.view.ISplashActivityView

interface ISplashActivityPresenter<V : ISplashActivityView, I : ISplashActivityInteractor> : IBasePresenter<V, I> {

    fun updateInitialData(data:SplashScreenActivity.Result)
}
