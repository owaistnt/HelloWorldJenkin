package com.shaadi.shaadilite.core.usecases

import com.shaadi.shaadilite.data.network.request.trackEvents.ChannelInfo

sealed class EventTypes(open val source: String,open val eventName: String,open val eventType: String)
data class NotificationSettingChanged(val notificationSetting: Boolean, val channel: Map<String, ChannelInfo>? =null, override val source: String) : EventTypes(source,"notification_settings_changed","track_notification_setting_changed")
data class TokenGenerated(override val source: String) : EventTypes(source,"device_token_captured","track_new_token_generated")
data class TrackLogin (override val source: String) : EventTypes(source,"login","track_login")
data class TrackLogout(override val source: String) : EventTypes(source,"logout","track_logout")