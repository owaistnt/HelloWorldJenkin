/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.data.network

import android.support.annotation.WorkerThread
import android.util.Log
import com.shaadi.shaadilite.core.usecases.EventUsecases
import com.shaadi.shaadilite.data.network.request.trackEvents.EventBody
import com.shaadi.shaadilite.data.network.response.trackEvents.ResponseData
import com.shaadi.shaadilite.data.network.retrofit_client.RetroClientInterface
import com.shaadi.shaadilite.utils.ApiUtils
import org.json.JSONObject
import retrofit2.Call
import retrofit2.http.*

class RetrofitApiHelperImpl : IApiHelper {

    @WorkerThread
    override fun trackNotificationEvents(options: Map<String, String>): JSONObject? {
        val trackApi by lazy { RetroClientInterface.zendInstance.create(NotificationTrackApi::class.java) }
        try {
            return trackApi.trackEvent(options).execute().body()
        } catch (exception: Exception) {
            Log.d("RetrofitApiHelperImpl",exception.toString())
            return null
        }
    }

    @WorkerThread
    override fun trackEvent(headerMap: Map<String, String>, memberlogin: String, rawReqModel: EventBody, callback: EventUsecases.ICallback?) {
        val trackApi by lazy { RetroClientInterface.soaInstance.create(TrackApi::class.java) }
        try {
            val defaultHeader = ApiUtils.getDefaultHeader()
            defaultHeader.putAll(headerMap)
            val data =trackApi.trackEvent(defaultHeader, memberlogin, rawReqModel).execute()
            if (data.isSuccessful) {
                callback?.onApiResponse(data.body())
            } else {
                callback?.onApiResponse(null)
            }

        } catch (exception: Exception) {
            callback?.onApiResponse(null)
        }
    }

    interface TrackApi {
        @POST("/api/track/{memberlogin}/events")
        fun trackEvent(@HeaderMap headerMap: Map<String, String>,
                       @Path(encoded = true, value = "memberlogin") memberlogin: String,
                       @Body rawReqModel: EventBody): Call<ResponseData>
    }

    interface NotificationTrackApi {

        @GET("notification/app-data-track")
        fun trackEvent(@QueryMap(encoded = true) headerMap: Map<String, String>): Call<JSONObject>
    }
}