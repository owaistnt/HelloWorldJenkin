/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.splash.model

import com.shaadi.shaadilite.BuildConfig
import com.shaadi.shaadilite.data.network.IApiHelper
import com.shaadi.shaadilite.data.preferences.IPreferenceHelper
import com.shaadi.shaadilite.ui.base.BaseInteractorImpl
import com.shaadi.shaadilite.ui.splash.SplashScreenActivity
import com.shaadi.shaadilite.utils.QueryHelper

class SplashActivityInteractorImpl(mPreferencesHelper: IPreferenceHelper, mIApiHelper: IApiHelper) :
        BaseInteractorImpl(mPreferencesHelper, mIApiHelper), ISplashActivityInteractor {

    override fun updateInitialData(data: SplashScreenActivity.Result) {
        preferencesHelper.gaid=data.gaid
        preferencesHelper.fcmToken=data.fcmToken
    }

    override fun isUserAlreadyLoggedIn(): Boolean =
            preferencesHelper.isLoggedIn


    override fun getInitialData(): SplashScreenActivity.Result =
            SplashScreenActivity.Result(
                    preferencesHelper.gaid,
                    preferencesHelper.fcmToken)


    override fun getReLoginUrl(): String =
            "${BuildConfig.SHAADI_LITE_URL}/default${preferencesHelper.let { QueryHelper.buildUpdateLastLoginQuery(it)}}"
}