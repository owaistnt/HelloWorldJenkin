/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.splash.model

import com.shaadi.shaadilite.ui.base.IBaseInteractor
import com.shaadi.shaadilite.ui.splash.SplashScreenActivity

interface ISplashActivityInteractor :IBaseInteractor {
    fun isUserAlreadyLoggedIn(): Boolean
    fun getInitialData(): SplashScreenActivity.Result
    fun updateInitialData(data:SplashScreenActivity.Result)
    fun getReLoginUrl():String
}