package com.shaadi.shaadilite.core.interactors

import android.util.Log
import com.google.gson.Gson
import com.shaadi.shaadilite.core.usecases.*
import com.shaadi.shaadilite.data.network.IApiHelper
import com.shaadi.shaadilite.data.network.request.trackEvents.EventBody
import com.shaadi.shaadilite.data.preferences.IPreferenceHelper
import com.shaadi.shaadilite.ui.base.BaseInteractorImpl
import com.shaadi.shaadilite.utils.FirebaseTracking

class EventInteractorImpl(val iPreferenceHelper: IPreferenceHelper, val apiHelperImpl: IApiHelper) : BaseInteractorImpl(iPreferenceHelper, apiHelperImpl), IEventInteractor {

    override fun trackEventOnThirdParty(eventTypes: EventTypes) {
        when (eventTypes) {
            is TrackLogin -> {
                FirebaseTracking.trackEvent(FirebaseTracking.LOGIN_CALLBACK)
            }
            is TrackLogout-> {
                FirebaseTracking.trackEvent(FirebaseTracking.LOGOUT_CALLBACK)
            }
        }
    }

    override fun getFcmToken(): String? {
        return iPreferenceHelper.fcmToken
    }

    override fun getDeviceId(): String? {
        return iPreferenceHelper.gaid
    }

    override fun getMemberLogin(): String? {
        return iPreferenceHelper.memberId
    }

    override fun trackEventOnServer(headerMap: Map<String, String>, rawReqModel: EventBody, icallback: EventUsecases.ICallback?) {
        Log.d("request", Gson().toJson(rawReqModel).toString())

        iPreferenceHelper.memberId?.let {
            apiHelperImpl.trackEvent(headerMap, it, rawReqModel, icallback)
        }
    }
}