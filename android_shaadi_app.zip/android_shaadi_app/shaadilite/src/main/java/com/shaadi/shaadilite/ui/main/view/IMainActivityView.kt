/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.main.view

import com.shaadi.shaadilite.ui.base.IBaseView

interface IMainActivityView :IBaseView{

    fun startPageLoading()
    fun startLoadingUrl(url:String)
    fun startNotificationStateChangeListenerService()
    fun clearSlangIfMainApp():Boolean
    fun setDefaultSlang()
    fun reloadPage()

}