/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.utils

import java.io.UnsupportedEncodingException
import java.net.URLEncoder


class QueryBuilder {
    val queryMapString = HashMap<String, String>()
    val queryMapBoolean = HashMap<String, Boolean>()

    fun addMap(key: String, value: String) = apply {
        this.queryMapString[key] = value
    }

    fun addMap(key: String, value: Boolean) = apply {
        this.queryMapBoolean[key] = value
    }

    fun build(): String {
        val query = StringBuffer()

        query.append(getStringKeyValue())
        query.append(getBooleanKeyValue())

        var finalQueryMap=query.toString()

        if(finalQueryMap.length>0)
            finalQueryMap="?$finalQueryMap"

        return finalQueryMap
    }

    private fun getStringKeyValue(): String {
        val stringBuilder = StringBuffer()

        for (keySet in queryMapString.entries) {
            if (stringBuilder.isNotEmpty()) {
                stringBuilder.append("&")
            }
            val value = keySet.value
            try {
                stringBuilder.append(URLEncoder.encode(keySet.key, "UTF-8"))
                stringBuilder.append("=")
                stringBuilder.append(URLEncoder.encode(value, "UTF-8"))
            } catch (e: UnsupportedEncodingException) {
                throw RuntimeException("This method requires UTF-8 encoding support", e)
            }

        }

        return stringBuilder.toString()

    }

    private fun getBooleanKeyValue(): String {
        val stringBuilder = StringBuffer()

        for (keySet in queryMapBoolean.entries) {
            if (stringBuilder.isNotEmpty()) {
                stringBuilder.append("&")
            }
            val value = keySet.value
            try {
                stringBuilder.append(URLEncoder.encode(keySet.key, "UTF-8"))
                stringBuilder.append("=")
                stringBuilder.append(value)
            } catch (e: UnsupportedEncodingException) {
                throw RuntimeException("This method requires UTF-8 encoding support", e)
            }
        }
        return stringBuilder.toString()

    }

    /**
     * returns the url parameters in a map
     *
     * @param query
     * @return map
     */
    fun queryToMap(query: String): Map<String, String> {
        val result = java.util.HashMap<String, String>()
        for (param in query.split("&".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()) {
            val pair = param.split("=".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            if (pair.size > 1) {
                result[pair[0]] = pair[1]
            } else {
                if (pair.size == 1)
                    result[pair[0]] = ""
            }
        }
        return result
    }

}
