package com.shaadi.shaadilite.service.notification

import android.app.IntentService
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.NotificationManagerCompat
import android.support.v4.app.RemoteInput
import com.shaadi.shaadilite.data.network.RetrofitApiHelperImpl
import com.shaadi.shaadilite.data.preferences.AppPreferenceHelper
import com.shaadi.shaadilite.service.notification.NotificationUtil.*

import com.shaadi.shaadilite.ui.main.MainActivity
import com.shaadi.shaadilite.utils.Utils

import com.shaadi.shaadilite.ui.main.MainActivity.Companion.KEY_LANDING_URL
import com.shaadi.shaadilite.utils.FirebaseTracking
import com.shaadi.shaadilite.utils.builder.NotificationTrackerBuilder




class NotificationIntentService : IntentService("NotificationIntentService") {

    override fun onHandleIntent(intent: Intent?) {

        if (intent != null) {
            val actionUrl = intent.action

            val remoteInput = RemoteInput.getResultsFromIntent(intent)
            if (remoteInput != null) {

                val charSequence = remoteInput.getCharSequence("")

            } else {
                if (actionUrl != null && actionUrl != "") {

                    val notifyIntent = Intent(this, MainActivity::class.java)
                    notifyIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    notifyIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    notifyIntent.putExtra(KEY_LANDING_URL, actionUrl)
                    startActivity(notifyIntent)

                    dismissNotification(intent)
                }


            }

        }
    }

    private fun dismissNotification(intent: Intent) {
        val bundle = intent.extras
        val notificationId = bundle?.getInt(NOTIFICATION_ID, -1) ?: -1
        if (notificationId != -1) {

            val notificationManagerCompat = NotificationManagerCompat.from(applicationContext)
            notificationManagerCompat.cancel(notificationId)
            intent.apply{
                val bundle = Bundle()
                bundle.putString("notificaton_type", getStringExtra(NOTIFICATION_TYPE))
                FirebaseTracking.trackEvent(FirebaseTracking.NOTIFICATION_OPENED, bundle)

                if (!AppPreferenceHelper.getInstance().memberId.isNullOrEmpty() && !AppPreferenceHelper.getInstance().abcToken.isNullOrEmpty()) {
                    val mIApiHelper = RetrofitApiHelperImpl()
                    val notificationTrackerBuilder = NotificationTrackerBuilder(this@NotificationIntentService)
                            .setType(getStringExtra(NOTIFICATION_TYPE))
                            .setState("" + Utils.NOTIFICATION_CLICKED)
                            .setTidNotNull(getStringExtra(NOTIFICATION_TID)).build()
                    mIApiHelper.trackNotificationEvents(notificationTrackerBuilder)
                }
            }

        }
    }
}