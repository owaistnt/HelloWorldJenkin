/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.main

import android.annotation.TargetApi
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.support.v4.app.NotificationManagerCompat
import android.util.Log
import android.view.View
import android.webkit.*
import android.widget.Toast
import com.shaadi.shaadilite.BuildConfig
import com.shaadi.shaadilite.R
import com.shaadi.shaadilite.analytics.AppsFlyerAnalytics
import com.shaadi.shaadilite.contants.ApiConstants.LOGIN_URL
import com.shaadi.shaadilite.contants.QueryKeyConstants
import com.shaadi.shaadilite.contants.QueryKeyConstants.KEY_APP_LANGUAGE
import com.shaadi.shaadilite.contants.QueryValueConstants
import com.shaadi.shaadilite.data.network.RetrofitApiHelperImpl
import com.shaadi.shaadilite.data.preferences.AppPreferenceHelper
import com.shaadi.shaadilite.service.notification.NotificationUtil.*
import com.shaadi.shaadilite.service.notification.notificationSettings.NotificationStateChangeIntentService
import com.shaadi.shaadilite.ui.base.BaseActivity
import com.shaadi.shaadilite.ui.base.SLChromeClient
import com.shaadi.shaadilite.ui.main.model.IMainActivityInteractor
import com.shaadi.shaadilite.ui.main.model.MainActivityInteractorImpl
import com.shaadi.shaadilite.ui.main.model.UserData
import com.shaadi.shaadilite.ui.main.presenter.MainActivityPresenterImpl
import com.shaadi.shaadilite.ui.main.presenter.WebViewUrlHelper
import com.shaadi.shaadilite.ui.main.view.IMainActivityView
import com.shaadi.shaadilite.utils.FirebaseTracking
import com.shaadi.shaadilite.utils.Utils
import com.shaadi.shaadilite.utils.WebviewCookieHandler
import com.shaadi.shaadilite.utils.builder.NotificationTrackerBuilder
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONException
import org.json.JSONObject
import java.net.URLDecoder

class MainActivity : BaseActivity(), SLChromeClient.ISLClientCallback, IMainActivityView {

    val TAG = this::class.java.simpleName
    lateinit var mPresenter: MainActivityPresenterImpl<IMainActivityView, IMainActivityInteractor>
    val mCookieHelper: WebviewCookieHandler by lazy {
        WebviewCookieHandler()
    }


    private var currenturl: String = ""


    companion object {
        const val KEY_LANDING_URL = "KEY_LANDING_URL"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //mCookieHelper.printAllCookie()
        setUp()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        processLanding(intent)
    }

    override fun setUp() {
        setDebugWebViewParams()
        setWebToNativeCallback()
        initialiseWebviewSetting()

        mPresenter = MainActivityPresenterImpl(MainActivityInteractorImpl(AppPreferenceHelper.getInstance(), RetrofitApiHelperImpl()))
        mPresenter.onAttach(this)


        processLanding(intent)
    }

    private fun processLanding(intent: Intent?) {
        var deeplinkUrl: String? = null

        intent?.data?.let {
            deeplinkUrl = Uri.parse(intent.data.toString()).query
        }
        mPresenter.processPageLoading(intent?.getStringExtra(KEY_LANDING_URL), isDeepLink(intent), deeplinkUrl)
        dismissNotification(intent)
    }

    override fun startLoadingUrl(url: String) {
        Log.d(TAG, url)
        currenturl = url
        mainActivityWebview.loadUrl(url)
    }

    fun isDeepLink(intent: Intent?): Boolean {
        return intent?.action?.equals("android.intent.action.VIEW", ignoreCase = true) == true
    }

    override fun startNotificationStateChangeListenerService() {
        val intent = Intent(this, NotificationStateChangeIntentService::class.java)
        startService(intent)
    }

    override fun startPageLoading() {
        mainActivityWebview.loadUrl(intent.getStringExtra(KEY_LANDING_URL))
    }

    fun setWebviewLayerType(settings: WebSettings) {
        when {
            Build.VERSION.SDK_INT >= 21 -> {
                settings.mixedContentMode = 0
                mainActivityWebview.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            }
            Build.VERSION.SDK_INT >= 19 -> mainActivityWebview.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            Build.VERSION.SDK_INT < 19 -> mainActivityWebview.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        sLChromeClient.onActivityResult(requestCode, resultCode, data)
    }

    private fun setWebToNativeCallback() {
        mainActivityWebview.addJavascriptInterface(WebViewJavaScriptInterface(), "app")
    }

    private val sLChromeClient by lazy { SLChromeClient(this, this) }

    private fun setDebugWebViewParams() {
        if (BuildConfig.DEBUG) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                WebView.setWebContentsDebuggingEnabled(true)
            }
        }
    }

    private fun initialiseWebviewSetting() {

        mainActivityWebview.settings.apply {
            loadWithOverviewMode = true
            pluginState = WebSettings.PluginState.ON
            allowFileAccess = true
            javaScriptEnabled = true
            loadWithOverviewMode = true
            allowFileAccess = true

            domStorageEnabled = true
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                safeBrowsingEnabled = false
            }

            setWebviewLayerType(this)
        }

        //error callback handling
        mainActivityWebview.apply {
            webViewClient = webClient
            //Other mainActivityWebview settings
            scrollBarStyle = WebView.SCROLLBARS_OUTSIDE_OVERLAY
            isScrollbarFadingEnabled = false
            webViewClient = SLClient()
            webChromeClient = sLChromeClient
        }

        if (Build.VERSION.SDK_INT >= 21) {
            // AppRTC requires third party cookies to work
            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptThirdPartyCookies(mainActivityWebview, true)
        }

    }

    val webClient = object : WebViewClient() {
        override fun onReceivedError(view: WebView, errorCode: Int, description: String, failingUrl: String) {
            showMessage("Failed loading app!")
        }
    }

    /*
     * JavaScript Interface. Web code can access methods in here
     * (as long as they have the @JavascriptInterface annotation)
     */
    inner class WebViewJavaScriptInterface {

        @JavascriptInterface
        fun markLoginInApp() {
            manualLogout=true
            if (BuildConfig.DEBUG) {
                try {
                    Toast.makeText(this@MainActivity, "Member Logged in ", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            mPresenter.onUserLoggedIn(getUserDetailFromCookies())
            removeLoginScreenFromStack()
        }

        @JavascriptInterface
        fun trackEvent(eventName: String, eventTypes: String) {
            Log.d("aps", "evet $eventName event types $eventTypes")
            try {
                AppsFlyerAnalytics.trackEvent(eventName, JSONObject(eventTypes), applicationContext)
            } catch (e: JSONException) {
                e.printStackTrace()
            }

        }

        @JavascriptInterface
        fun clearWebviewCache() {
            mainActivityWebview.post { mainActivityWebview.clearCache(true) }
        }

        @JavascriptInterface
        fun markLogOutInApp() {
            if (BuildConfig.DEBUG) {
                try {
                    Toast.makeText(this@MainActivity, "Member Logged out ", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            mPresenter.onUserLoggedOut()
        }
    }

    var manualLogout=false

    override fun reloadPage() {
        mainActivityWebview.post {
            mainActivityWebview.clearCache(true)
            if (manualLogout) {
                mainActivityWebview.reload()
                manualLogout=false
            }

            mCookieHelper.printAllCookie()
        }
    }


    private fun getUserDetailFromCookies() = with(mCookieHelper) {
        val abc = URLDecoder.decode(getCookie("abc"), "UTF-8")
        val memberlogin = Utils.getMemberIdFromAbc(abc)
        UserData(memberlogin, abc)
    }


    inner class SLClient : WebViewClient() {

        @TargetApi(Build.VERSION_CODES.N)
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            Log.i(TAG, "loading ${request?.url.toString()}")

            request?.url?.let {
                mPresenter.handleWebUrl(it.toString(), object : WebViewUrlHelper.Callback {
                    override fun loadUrl(url: String) {
                        view?.loadUrl(url)
                    }

                    override fun loadExternalUrl() {
                        view?.context?.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(it.toString())))
                    }

                    override fun loadUrl() {
                        view?.loadUrl(it.toString())
                    }
                })
            }

            return true
        }

        @SuppressWarnings("deprecation")
        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            Log.i(TAG, "loading ${url}")

            mPresenter.handleWebUrl(url, object : WebViewUrlHelper.Callback {
                override fun loadUrl(url: String) {
                    view.loadUrl(url)
                }

                override fun loadExternalUrl() {
                    view.context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }

                override fun loadUrl() {
                    view.loadUrl(url)
                }
            })
            return true
        }

        override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
            super.onReceivedError(view, errorCode, description, failingUrl)
            failingUrl?.let { showErrorLayer(it) }
            Log.i(TAG, "error loading ${failingUrl}")
        }

        //Show loader on url load
        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            if (!url.contains(BuildConfig.NON_LOADER_URL))
                showProgressBar()
        }

        // Called when all page resources loaded
        override fun onPageFinished(view: WebView, url: String) {
            if (!url.contains(BuildConfig.NON_LOADER_URL))
                hideProgressBar()
        }

    }

    private fun showErrorLayer(failingUrl: String) {
        ll_error.visibility = View.VISIBLE
        mainActivityWebview?.loadUrl("about:blank")
        currenturl = failingUrl
    }

    fun showProgressBar() {
        if (!isFinishing && actMain_progressbar.visibility == View.GONE)
            actMain_progressbar.visibility = View.VISIBLE
    }

    fun hideProgressBar() {
        if (!isFinishing && actMain_progressbar.visibility == View.VISIBLE)
            actMain_progressbar.visibility = View.GONE
    }

    override fun showImageChooserDialog(chooserIntent: Intent, requestCode: Int) {
        startActivityForResult(chooserIntent, requestCode)
    }

    override fun onBackPressed() {

        if (mainActivityWebview.canGoBack()) {
            if (mainActivityWebview.canGoBack()) {
                if (handleBackPressForLogin())
                    handleBackPress()
                else
                    mainActivityWebview.goBack()
            }
        } else {
            if (mPresenter.isLoggedInMember()) {
                handleBackPress()
            } else
                super.onBackPressed()
        }
    }

    var backHitCount = 0

    private fun handleBackPressForLogin(): Boolean {
        val mWebBackForwardList = mainActivityWebview.copyBackForwardList()
        if (mWebBackForwardList.currentIndex > 0)
            if (mWebBackForwardList.getItemAtIndex(mWebBackForwardList.currentIndex - 1).url.contains(LOGIN_URL)) {
                return true
            }
        return false
    }

    private fun handleBackPress() {
        backHitCount++
        if (backHitCount > 1) {
            finish()
        } else {
            Toast.makeText(applicationContext,
                    "Press Back again to exit", Toast.LENGTH_SHORT)
                    .show()
            Handler().postDelayed({ backHitCount = 0 }, 4000)
        }

    }

    override fun onDestroy() {
        mPresenter.onDetach()
        super.onDestroy()
    }

    override fun setDefaultSlang() {
        val defaultCookie = "${QueryKeyConstants.KEY_APP_LANGUAGE}=${QueryValueConstants.VALUE_APP_LANGUAGE};"
        mCookieHelper.setCookie(defaultCookie)
    }

    override fun clearSlangIfMainApp(): Boolean {
        if (QueryValueConstants.MAIN_APP_SLANG.equals(QueryValueConstants.VALUE_APP_LANGUAGE)) {
            mCookieHelper.setCookie("${KEY_APP_LANGUAGE}=;${SET_EXPIRY_TO_DELETE_COOKIE}")
            return true
        }
        return false
    }

    private fun removeLoginScreenFromStack() {
        val broadcastIntent = Intent()
        broadcastIntent.action = "com.package.ACTION_LOGOUT"
        sendBroadcast(broadcastIntent)
    }

    private fun dismissNotification(intent: Intent?) {

        val notificationId = intent?.getIntExtra(NOTIFICATION_ID, -1) ?: -1
        if (notificationId != -1) {

            val notificationManagerCompat = NotificationManagerCompat.from(applicationContext)
            notificationManagerCompat.cancel(notificationId)
            intent?.apply {
                val bundle = Bundle()
                bundle.putString("notificaton_type", getStringExtra(NOTIFICATION_TYPE))
                FirebaseTracking.trackEvent(FirebaseTracking.NOTIFICATION_OPENED, bundle)

                if (!AppPreferenceHelper.getInstance().memberId.isNullOrEmpty() && !AppPreferenceHelper.getInstance().abcToken.isNullOrEmpty()) {
                    val mIApiHelper = RetrofitApiHelperImpl()
                    val notificationTrackerBuilder = NotificationTrackerBuilder(this@MainActivity)
                            .setType(getStringExtra(NOTIFICATION_TYPE))
                            .setState("" + Utils.NOTIFICATION_CLICKED)
                            .setTidNotNull(getStringExtra(NOTIFICATION_TID)).build()
                    AsyncTask.execute {
                        mIApiHelper.trackNotificationEvents(notificationTrackerBuilder)
                    }
                }
            }

        }
        val it = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
        this@MainActivity.sendBroadcast(it)
    }

    val SET_EXPIRY_TO_DELETE_COOKIE = "expires=Sat, 1 Jan 2000 00:00:01 UTC;"


    fun reload(view: View) {
        checkAndLoad(currenturl)
    }

    private fun checkAndLoad(url: String) {
        if (Utils.isNetworkAvailable(applicationContext)) {
            mainActivityWebview.loadUrl(url)
            actMain_progressbar.visibility = View.VISIBLE
            ll_error.visibility = View.GONE
        } else {
            actMain_progressbar.visibility = View.GONE
            ll_error.visibility = View.VISIBLE
        }
    }
}
