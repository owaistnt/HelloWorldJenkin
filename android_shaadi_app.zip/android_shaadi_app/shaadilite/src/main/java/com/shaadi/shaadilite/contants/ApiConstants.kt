/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.contants

import com.shaadi.shaadilite.BuildConfig

object ApiConstants {
    const val REGISTRATION_URL= BuildConfig.SHAADI_LITE_URL+"/registration/user"
    const val LOGIN_URL= BuildConfig.SHAADI_LITE_URL+"/registration/user/login"
    const val NATIVE_FAKE_URL= "http://native_app_fake_url/"
}