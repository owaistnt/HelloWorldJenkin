/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.utils

import android.app.ProgressDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.text.TextUtils
import com.google.android.gms.ads.identifier.AdvertisingIdClient
import com.google.android.gms.common.GooglePlayServicesNotAvailableException
import com.google.android.gms.common.GooglePlayServicesRepairableException
import com.google.firebase.iid.FirebaseInstanceId
import com.shaadi.shaadilite.BuildConfig
import com.shaadi.shaadilite.R
import com.shaadi.shaadilite.contants.QueryValueConstants
import com.shaadi.shaadilite.data.preferences.AppPreferenceHelper
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.math.BigInteger
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.*


object Utils {


    fun showLoadingDialog(context: Context): ProgressDialog {
        val progressDialog = ProgressDialog(context)
        progressDialog.show()
        if (progressDialog.window != null) {
            progressDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }
        progressDialog.setContentView(R.layout.progress_dialog)
        progressDialog.isIndeterminate = true
        progressDialog.setCancelable(false)
        progressDialog.setCanceledOnTouchOutside(false)
        return progressDialog
    }

    /**
     * Retrieve the Android Advertising Id
     *    *
     * This method must be invoked from a background thread.
     */
    @Synchronized
    fun getGAID(context: Context): String {

        var idInfo: AdvertisingIdClient.Info? = null
        try {
            idInfo = AdvertisingIdClient.getAdvertisingIdInfo(context)
        } catch (e: GooglePlayServicesNotAvailableException) {
            e.printStackTrace()
        } catch (e: GooglePlayServicesRepairableException) {
            e.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }

        var advertId: String
        try {
            advertId = idInfo!!.id
        } catch (e: NullPointerException) {
            advertId = getUniqueIdentifier()
        }

        return advertId
    }

    /*this will return unique device Id (generally we will get device id from telephone manager)
     *in case there is not telephone manager this will return android id
     * */
    private fun getUniqueIdentifier(): String {
        var uniqueId = FirebaseInstanceId.getInstance().id
        if (TextUtils.isEmpty(uniqueId)) {
            uniqueId = UUID.randomUUID().toString()
        }
        return uniqueId
    }


    fun getMemberIdFromAbc(abcToken: String?): String? {
        val arrayOfSPlit = abcToken?.split("|")
        var memberLogin: String? = null
        arrayOfSPlit?.let {
            if (arrayOfSPlit.size >= 2) {
                memberLogin = arrayOfSPlit[1]
            }
        }
        return memberLogin
    }

    fun generateMD5Hash(appListingInfos: JSONObject): String? {
        var hash: String? = null
        try {

            val messageDigest: MessageDigest

            messageDigest = MessageDigest.getInstance("MD5")

            messageDigest.update(appListingInfos.toString().toByteArray(),
                    0, appListingInfos.toString().length)
            hash = BigInteger(1, messageDigest.digest()).toString(16)
        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        return hash
    }

    fun addDefaultParameter(context: Context,
                            paramMap: HashMap<String, String>?): Map<String, String> {
        var map = paramMap

        if (map == null) {
            map =  HashMap()
        }
        try {
            map["abc"] = URLEncoder.encode(AppPreferenceHelper.getInstance().abcToken)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        map["ml"] = AppPreferenceHelper.getInstance().memberId!!
        map["appver"] = BuildConfig.VERSION_NAME
        map["auth"] = getAuthMd5sum()
        map["os"] = QueryValueConstants.VALUE_OS
        try {
            map["deviceid"] = URLEncoder.encode(AppPreferenceHelper.getInstance().gaid, "UTF-8")
        } catch (e: Exception) {
            e.printStackTrace()
        }

        map["_ts"] = "" + Date().time
        map["format"] = "json"

        return map
    }

    fun getAuthMd5sum(): String {
        val `val` = (AppPreferenceHelper.getInstance().abcToken
                + CONSTANT_PARAM)
        return md5(`val`)
    }

    fun md5(ml: String): String {
        val MD5 = "MD5"
        try {
            // Create MD5 Hash
            val digest = MessageDigest.getInstance(MD5)
            digest.update(ml.toByteArray())
            val messageDigest = digest.digest()

            // Create Hex String
            val hexString = StringBuilder()
            for (aMessageDigest in messageDigest) {
                var h = Integer.toHexString(0xFF and aMessageDigest.toInt())
                while (h.length < 2)
                    h = "0$h"
                hexString.append(h)
            }
            return hexString.toString()

        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        }

        return ""
    }

    fun  getLastString(myString: String, numberOfString: Int): String {
        return if (myString.length > numberOfString)
            myString.substring(myString.length - numberOfString)
        else
            myString
    }


    val CONSTANT_PARAM = "7007"
    val NOTIFICATION_DELIVERED = 1
    val NOTIFICATION_CLICKED = 2

    fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting
    }

}