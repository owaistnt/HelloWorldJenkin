/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.contants

import android.os.Build
import com.shaadi.shaadilite.BuildConfig

object QueryValueConstants {
    val VALUE_REG_MOD="app"
    val VALUE_OS="native-android-lite"
    val VALUE_APP_VERSION=BuildConfig.VERSION_NAME
    val VALUE_MANUFACTURER= Build.MANUFACTURER
    val VALUE_MODEL=Build.MODEL
    val VALUE_APP_LANGUAGE=BuildConfig.SHAADI_LITE_APP_LANGUAGE
    var VALUE_RESPONSE_FORMAT = "json"
    var VALUE_APP_LAUNCH= "1"
    val MAIN_APP_SLANG: String = "en-US";
}