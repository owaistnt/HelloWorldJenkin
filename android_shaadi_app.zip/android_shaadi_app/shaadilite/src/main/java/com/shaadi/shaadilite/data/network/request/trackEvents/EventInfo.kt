package com.shaadi.shaadilite.data.network.request.trackEvents

import com.shaadi.shaadilite.BuildConfig

class EventInfo {
    var source: String?=null
    var device_token: String?=null
    lateinit var device_id: String
    val app_version: Int=BuildConfig.VERSION_CODE
    val app_type: String=BuildConfig.APP_TYPE
    val app_platform: String=BuildConfig.APP_PLATFORM
    var channel: Map<String, ChannelInfo>?=null
    var system_settings:Boolean?=null

}