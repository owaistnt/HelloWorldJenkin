/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.login.view

import com.shaadi.shaadilite.ui.base.IBaseView

interface ILoginActivityView :IBaseView{
    fun openRegistrationScreen(loginUrl:String )
    fun openLoginScreen(landingUrl:String )
    fun setCookies(cookies:ArrayList<String>)
}