/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.base

open class BasePresenterImpl<V : IBaseView, I : IBaseInteractor>(mvpInteractor: I) : IBasePresenter<V, I> {

    override var mvpView: V? = null

    override var interactor: I? = null

    override val isViewAttached: Boolean
        get() = mvpView != null

    init {
        interactor = mvpInteractor
    }

    override fun onAttach(mvpView: V) {
        this.mvpView = mvpView
    }

    override fun onDetach() {
        mvpView = null
        interactor = null
    }

    @Throws(MvpViewNotAttachedException::class)
    override fun checkViewAttached() {
        if (!isViewAttached) throw MvpViewNotAttachedException()
    }


    override fun setUserAsLoggedOut() {
        interactor?.setAccessToken(null)
    }

    class MvpViewNotAttachedException : RuntimeException("Please call Presenter.onAttach(IBaseView) before" + " requesting data to the Presenter")

    companion object {

        private val TAG = "BasePresenterImpl"
    }
}
