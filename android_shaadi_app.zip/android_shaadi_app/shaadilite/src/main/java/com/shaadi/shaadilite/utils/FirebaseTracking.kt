package com.shaadi.shaadilite.utils

import android.content.Context
import android.os.Bundle
import android.util.Log
import com.google.firebase.analytics.FirebaseAnalytics

object FirebaseTracking {


    private var mFirebaseAnalytics: FirebaseAnalytics? = null

    @JvmStatic
    fun init(context: Context) {
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(context)
    }

    @JvmOverloads
    fun trackEvent(eventType: String, bundle: Bundle=Bundle()) {
        // bundle.putString("Event_type", eventType)
        // bundle.putString("App_version", BuildConfig.VERSION_CODE.toString())
        // bundle.putString("Action_locations", actionLocation)
        // bundle.putString("OS_version", android.os.Build.VERSION.SDK_INT.toString())
        // bundle.putString("Manufacturer", android.os.Build.MANUFACTURER.toString())
        Log.d("logEvent", eventType)
        mFirebaseAnalytics!!.logEvent(eventType, bundle)
    }

    const val NOTIFICATION_DELIVERED= "notification_delivered"
    const val NOTIFICATION_OPENED= "notification_opened"

    const val NATIVE_CLICK_SIGN_IN= "native_click_sign_in"
    const val NATIVE_CLICK_REGISTRATION= "native_click_registration"

    const val LOGIN_CALLBACK= "logged_in"
    const val LOGOUT_CALLBACK= "logged_out"
}

