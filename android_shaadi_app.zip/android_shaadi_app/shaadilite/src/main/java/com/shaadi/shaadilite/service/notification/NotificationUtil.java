/*
 * Copyright (C) 2017 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.shaadi.shaadilite.service.notification;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;

import com.shaadi.shaadilite.R;
import com.shaadi.shaadilite.extensions.ImageExtensionsKt;
import com.shaadi.shaadilite.ui.main.MainActivity;
import com.shaadi.shaadilite.utils.ImageUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.shaadi.shaadilite.ui.main.MainActivity.KEY_LANDING_URL;

/**
 * Simplifies common {@link Notification} tasks.
 */
public class NotificationUtil {
    public static final String NOTIFICATION_ID = "NOTIFICATION_ID";
    public static final String NOTIFICATION_TID = "NOTIFICATION_TID";
    public static final String NOTIFICATION_TYPE = "NOTIFICATION_TYPE";

    private static final String MESSAGE_STYLE = "message";
    private static final String BIG_PICTURE_STYLE = "picture";

    private static final Map<String, Integer> IMAGE_MAP = new HashMap<String, Integer>() {{
        put("icon_button_accept", R.drawable.ic_notification_action_accept);
        put("icon_button_email", R.drawable.ic_notification_action_email);
        put("icon_button_female", R.drawable.ic_notification_action_female);
        put("icon_button_male", R.drawable.ic_notification_action_male);
        put("icon_female", R.drawable.ic_notification_female);
        put("icon_male", R.drawable.ic_notification_male);
    }};

    /**
     * Generates a BIG_TEXT_STYLE Notification that supports both phone/tablet and wear. For devices
     * on API level 16 (4.1.x - Jelly Bean) and after, displays BIG_TEXT_STYLE. Otherwise, displays
     * a basic notification.
     */


    public static void generateNotification(Context context, NotificationData notificationData) {
        if (MESSAGE_STYLE.equalsIgnoreCase(notificationData.getStyle())) {
            generateBigTextStyleNotification(context, notificationData);
        } else {
            generateBigPictureStyleNotification(context, notificationData);
        }
    }

    public static void generateBigTextStyleNotification(Context context, NotificationData notificationData) {


        // Main steps for building a BIG_TEXT_STYLE notification:
        //      0. Get your data
        //      1. Create/Retrieve Notification Channel for O and beyond devices (26+)
        //      2. Build the BIG_TEXT_STYLE
        //      3. Set up main Intent for notification
        //      4. Create additional Actions for the Notification
        //      5. Build and issue the notification

        // 0. Get your data (everything unique per Notification).
        MockDatabase.BigTextStyleReminderAppData bigTextStyleReminderAppData =
                MockDatabase.getBigTextStyleData(notificationData);

        // 1. Create/Retrieve Notification Channel for O and beyond devices (26+).
        String notificationChannelId =
                NotificationUtil.createNotificationChannel(context, bigTextStyleReminderAppData);


        // 2. Build the BIG_TEXT_STYLE.
        NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle()
                // Overrides ContentText in the big form of the template.
                .bigText(bigTextStyleReminderAppData.getBigText())
                // Overrides ContentTitle in the big form of the template.
                .setBigContentTitle(bigTextStyleReminderAppData.getBigContentTitle())
                // Summary line after the detail section in the big form of the template.
                // Note: To improve readability, don't overload the user with info. If Summary Text
                // doesn't add critical information, you should skip it.
                // .setSummaryText(bigTextStyleReminderAppData.getSummaryText())
                ;


        // 3. Set up main Intent for notification.
        Intent notifyIntent = new Intent(context, MainActivity.class);
        notifyIntent.putExtra(KEY_LANDING_URL, notificationData.getLandingUrl());
        notifyIntent.putExtra(NOTIFICATION_ID, notificationData.getNotificationId());
        notifyIntent.putExtra(NOTIFICATION_TID, notificationData.getTid());
        notifyIntent.putExtra(NOTIFICATION_TYPE, notificationData.getType());


        // When creating your Intent, you need to take into account the back state, i.e., what
        // happens after your Activity launches and the user presses the back button.

        // There are two options:
        //      1. Regular activity - You're starting an Activity that's part of the application's
        //      normal workflow.

        //      2. Special activity - The user only sees this Activity if it's started from a
        //      notification. In a sense, the Activity extends the notification by providing
        //      information that would be hard to display in the notification itself.

        // For the BIG_TEXT_STYLE notification, we will consider the activity launched by the main
        // Intent as a special activity, so we will follow option 2.

        // For an example of option 1, check either the MESSAGING_STYLE or BIG_PICTURE_STYLE
        // examples.

        // For more information, check out our dev article:
        // https://developer.android.com/training/notify-user/navigation.html

        // Sets the Activity to start in a new, empty task
        notifyIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        PendingIntent notifyPendingIntent =
                PendingIntent.getActivity(
                        context,
                        0,
                        notifyIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT
                );


        // 5. Build and issue the notification.

        // Because we want this to be a new notification (not updating a previous notification), we
        // create a new Builder. Later, we use the same global builder to get back the notification
        // we built here for the snooze action, that is, canceling the notification and relaunching
        // it several seconds later.

        // Notification Channel Id is ignored for Android pre O (26).
        NotificationCompat.Builder notificationCompatBuilder =
                new NotificationCompat.Builder(
                        context.getApplicationContext(), notificationChannelId);

        GlobalNotificationBuilder.setNotificationCompatBuilderInstance(notificationCompatBuilder);

        notificationCompatBuilder
                // BIG_TEXT_STYLE sets title and content for API 16 (4.1 and after).
                .setStyle(bigTextStyle)
                // Title for API <16 (4.0 and below) devices.
                .setContentTitle(bigTextStyleReminderAppData.getContentTitle())
                // Content for API <24 (7.0 and below) devices.
                .setContentText(bigTextStyleReminderAppData.getContentText())
                .setSmallIcon(R.drawable.ic_stat)
                .setLargeIcon(getNotificationIcon(context,notificationData.getIconImageUrl()))
                .setContentIntent(notifyPendingIntent)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                // Set primary color (important for Wear 2.0 Notifications).
                .setColor(ContextCompat.getColor(context.getApplicationContext(), R.color.colorPrimary))

                // SIDE NOTE: Auto-bundling is enabled for 4 or more notifications on API 24+ (N+)
                // devices and all Wear devices. If you have more than one notification and
                // you prefer a different summary notification, set a group key and create a
                // summary notification via
                // .setGroupSummary(true)
                // .setGroup(GROUP_KEY_YOUR_NAME_HERE)

                //.setCategory(notificationData.getCategory())

                // Sets priority for 25 and below. For 26 and above, 'priority' is deprecated for
                // 'importance' which is set in the NotificationChannel. The integers representing
                // 'priority' are different from 'importance', so make sure you don't mix them.
                .setPriority(bigTextStyleReminderAppData.getPriority())

                // Sets lock-screen visibility for 25 and below. For 26 and above, lock screen
                // visibility is set in the NotificationChannel.
                .setVisibility(bigTextStyleReminderAppData.getChannelLockscreenVisibility());

        buildActions(context, notificationCompatBuilder, notificationData);

        Notification notification = notificationCompatBuilder.build();
        NotificationManagerCompat mNotificationManagerCompat = NotificationManagerCompat.from(context.getApplicationContext());
        mNotificationManagerCompat.notify(notificationData.getNotificationId(), notification);
    }

    private static Bitmap getNotificationIcon(Context context,String imageUrl) {
        if(TextUtils.isEmpty(imageUrl))
        return BitmapFactory.decodeResource(context.getResources(),
                R.drawable.ic_notification_female);
        else {
            return ImageUtils.INSTANCE.getBitmap(imageUrl);
        }
    }

    public static void generateBigPictureStyleNotification(final Context context, final NotificationData notificationData) {


        // Main steps for building a BIG_PICTURE_STYLE notification:
        //      0. Get your data
        //      1. Create/Retrieve Notification Channel for O and beyond devices (26+)
        //      2. Build the BIG_PICTURE_STYLE
        //      3. Set up main Intent for notification
        //      4. Set up RemoteInput, so users can input (keyboard and voice) from notification
        //      5. Build and issue the notification

        // 0. Get your data (everything unique per Notification).
        MockDatabase.BigPictureStyleSocialAppData bigPictureStyleSocialAppData =
                MockDatabase.getBigPictureStyleData(notificationData);

        // 1. Create/Retrieve Notification Channel for O and beyond devices (26+).
        String notificationChannelId =
                NotificationUtil.createNotificationChannel(context, bigPictureStyleSocialAppData);

        // 2. Build the BIG_PICTURE_STYLE.
        final NotificationCompat.BigPictureStyle bigPictureStyle = new NotificationCompat.BigPictureStyle()
                // Overrides ContentTitle in the big form of the template.
                .setBigContentTitle(bigPictureStyleSocialAppData.getBigContentTitle())
                // Summary line after the detail section in the big form of the template.
                .setSummaryText(bigPictureStyleSocialAppData.getSummaryText());

        // 3. Set up main Intent for notification.
        Intent notifyIntent = new Intent(context, MainActivity.class);
        notifyIntent.putExtra(KEY_LANDING_URL, notificationData.getLandingUrl());
        notifyIntent.putExtra(NOTIFICATION_TID, notificationData.getTid());
        notifyIntent.putExtra(NOTIFICATION_TYPE, notificationData.getType());


        // Gets a PendingIntent containing the entire back stack.
        PendingIntent mainPendingIntent =
                PendingIntent.getActivity(
                        context,
                        0,
                        notifyIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT
                );


        // 5. Build and issue the notification.

        // Because we want this to be a new notification (not updating a previous notification), we
        // create a new Builder. Later, we use the same global builder to get back the notification
        // we built here for a comment on the post.

        final NotificationCompat.Builder notificationCompatBuilder =
                new NotificationCompat.Builder(context.getApplicationContext(), notificationChannelId);

        GlobalNotificationBuilder.setNotificationCompatBuilderInstance(notificationCompatBuilder);

        notificationCompatBuilder
                // BIG_PICTURE_STYLE sets title and content for API 16 (4.1 and after).
                .setStyle(bigPictureStyle)
                // Title for API <16 (4.0 and below) devices.
                .setContentTitle(bigPictureStyleSocialAppData.getContentTitle())
                // Content for API <24 (7.0 and below) devices.
                .setContentText(bigPictureStyleSocialAppData.getContentText())
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(mainPendingIntent)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                // Set primary color (important for Wear 2.0 Notifications).
                .setColor(ContextCompat.getColor(context.getApplicationContext(), R.color.colorPrimary))

                // SIDE NOTE: Auto-bundling is enabled for 4 or more notifications on API 24+ (N+)
                // devices and all Wear devices. If you have more than one notification and
                // you prefer a different summary notification, set a group key and create a
                // summary notification via
                // .setGroupSummary(true)
                // .setGroup(GROUP_KEY_YOUR_NAME_HERE)

                //.setSubText(Integer.toString(1))
                //.setCategory(notificationData.getCategory())

                // Sets priority for 25 and below. For 26 and above, 'priority' is deprecated for
                // 'importance' which is set in the NotificationChannel. The integers representing
                // 'priority' are different from 'importance', so make sure you don't mix them.
                .setPriority(bigPictureStyleSocialAppData.getPriority())

                // Sets lock-screen visibility for 25 and below. For 26 and above, lock screen
                // visibility is set in the NotificationChannel.
                .setVisibility(bigPictureStyleSocialAppData.getChannelLockscreenVisibility());


        Bitmap bitmap = ImageExtensionsKt.FromUrl(bigPictureStyleSocialAppData.getBigImage());

        bigPictureStyle.bigPicture(bitmap);
        bigPictureStyle.bigLargeIcon(null); // when user drag the notification to see fully , then large icon should be hidden which is set in next line 'setLargeIcon()'
        notificationCompatBuilder.setLargeIcon(bitmap);
        buildActions(context, notificationCompatBuilder, notificationData);
        Notification notification = notificationCompatBuilder.build();
        NotificationManagerCompat mNotificationManagerCompat = NotificationManagerCompat.from(context.getApplicationContext());
        mNotificationManagerCompat.notify(notificationData.getNotificationId(), notification);


        /*Glide.with(context).asBitmap().load(bigPictureStyleSocialAppData.getBigImage()).into(new SimpleTarget<Bitmap>() {
            @Override
            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                bigPictureStyle.bigPicture(resource);
                bigPictureStyle.bigLargeIcon(null); // when user drag the notification to see fully , then large icon should be hidden which is set in next line 'setLargeIcon()'
                notificationCompatBuilder.setLargeIcon(resource);
                buildActions(context, notificationCompatBuilder, notificationData);
                Notification notification = notificationCompatBuilder.build();
                NotificationManagerCompat mNotificationManagerCompat = NotificationManagerCompat.from(context.getApplicationContext());
                mNotificationManagerCompat.notify(notificationData.getNotificationId(), notification);
            }
        });*/


    }


//    public static void generateInboxStyleNotification(final Context context, final NotificationData notificationData) {
//
//
//        // Main steps for building a INBOX_STYLE notification:
//        //      0. Get your data
//        //      1. Create/Retrieve Notification Channel for O and beyond devices (26+)
//        //      2. Build the INBOX_STYLE
//        //      3. Set up main Intent for notification
//        //      4. Build and issue the notification
//
//        // 0. Get your data (everything unique per Notification).
//        MockDatabase.InboxStyleEmailAppData inboxStyleEmailAppData =
//                MockDatabase.getInboxStyleData(notificationData);
//
//        // 1. Create/Retrieve Notification Channel for O and beyond devices (26+).
//        String notificationChannelId =
//                NotificationUtil.createNotificationChannel(context, inboxStyleEmailAppData);
//
//        // 2. Build the INBOX_STYLE.
//        NotificationCompat.InboxStyle inboxStyle = new NotificationCompat.InboxStyle()
//                // This title is slightly different than regular title, since I know INBOX_STYLE is
//                // available.
//                .setBigContentTitle(inboxStyleEmailAppData.getBigContentTitle())
//                .setSummaryText(inboxStyleEmailAppData.getSummaryText());
//
//        // Add each summary line of the new emails, you can add up to 5.
//        for (String summary : inboxStyleEmailAppData.getIndividualEmailSummary()) {
//            inboxStyle.addLine(summary);
//        }
//
//        // 3. Set up main Intent for notification.
//        Intent mainIntent = new Intent(context, BigPictureSocialMainActivity.class);
//
//
//        // Gets a PendingIntent containing the entire back stack.
//        PendingIntent mainPendingIntent =
//                PendingIntent.getActivity(
//                        context,
//                        0,
//                        mainIntent,
//                        PendingIntent.FLAG_UPDATE_CURRENT
//                );
//
//        // 4. Build and issue the notification.
//
//        // Because we want this to be a new notification (not updating a previous notification), we
//        // create a new Builder. However, we don't need to update this notification later, so we
//        // will not need to set a global builder for access to the notification later.
//
//        final NotificationCompat.Builder notificationCompatBuilder =
//                new NotificationCompat.Builder(context.getApplicationContext(), notificationChannelId);
//
//        GlobalNotificationBuilder.setNotificationCompatBuilderInstance(notificationCompatBuilder);
//
//        notificationCompatBuilder
//
//                // INBOX_STYLE sets title and content for API 16+ (4.1 and after) when the
//                // notification is expanded.
//                .setStyle(inboxStyle)
//
//                // Title for API <16 (4.0 and below) devices and API 16+ (4.1 and after) when the
//                // notification is collapsed.
//                .setContentTitle(inboxStyleEmailAppData.getContentTitle())
//
//                // Content for API <24 (7.0 and below) devices and API 16+ (4.1 and after) when the
//                // notification is collapsed.
//                .setContentText(inboxStyleEmailAppData.getContentText())
//                .setSmallIcon(R.mipmap.ic_launcher)
//                .setContentIntent(mainPendingIntent)
//                .setDefaults(NotificationCompat.DEFAULT_ALL)
//                // Set primary color (important for Wear 2.0 Notifications).
//                .setColor(ContextCompat.getColor(context.getApplicationContext(), R.color.colorPrimary))
//
//                // SIDE NOTE: Auto-bundling is enabled for 4 or more notifications on API 24+ (N+)
//                // devices and all Wear devices. If you have more than one notification and
//                // you prefer a different summary notification, set a group key and create a
//                // summary notification via
//                // .setGroupSummary(true)
//                // .setGroup(GROUP_KEY_YOUR_NAME_HERE)
//
//                // Sets large number at the right-hand side of the notification for API <24 devices.
//                .setSubText(Integer.toString(inboxStyleEmailAppData.getNumberOfNewEmails()))
//
//                .setCategory(notificationData.getCategory())
//
//                // Sets priority for 25 and below. For 26 and above, 'priority' is deprecated for
//                // 'importance' which is set in the NotificationChannel. The integers representing
//                // 'priority' are different from 'importance', so make sure you don't mix them.
//                .setPriority(inboxStyleEmailAppData.getPriority())
//
//                // Sets lock-screen visibility for 25 and below. For 26 and above, lock screen
//                // visibility is set in the NotificationChannel.
//                .setVisibility(inboxStyleEmailAppData.getChannelLockscreenVisibility());
//
//        // If the phone is in "Do not disturb mode, the user will still be notified if
//        // the sender(s) is starred as a favorite.
//        for (String name : inboxStyleEmailAppData.getParticipants()) {
//            notificationCompatBuilder.addPerson(name);
//        }
//
//
//
//    }
//
//
//    public static void generateSummaryStyleNotification(final Context context, final NotificationData notificationData) {
//
//        NotificationManagerCompat mNotificationManagerCompat = NotificationManagerCompat.from(context.getApplicationContext());
//        ArrayList<Notification> notificationCompatArrayList = new ArrayList<>();
//        String notificationChannelId = null;
//        for (NotificationData eachData : notificationData.getNotificatioList()) {
//
//
//            // Main steps for building a INBOX_STYLE notification:
//            //      0. Get your data
//            //      1. Create/Retrieve Notification Channel for O and beyond devices (26+)
//            //      2. Build the INBOX_STYLE
//            //      3. Set up main Intent for notification
//            //      4. Build and issue the notification
//
//            // 0. Get your data (everything unique per Notification).
//            MockDatabase.SummaryBigTextStyeAppData summaryBigTextStyeAppData =
//                    MockDatabase.getSummaryStyleData(eachData);
//
//            // 1. Create/Retrieve Notification Channel for O and beyond devices (26+).
//            notificationChannelId =
//                    NotificationUtil.createNotificationChannel(context, summaryBigTextStyeAppData);
//
//            // 2. Build the INBOX_STYLE.
//            NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle()
//                    // This title is slightly different than regular title, since I know INBOX_STYLE is
//                    // available.
//                    .setBigContentTitle(summaryBigTextStyeAppData.getContentTitle())
//                    .setSummaryText(summaryBigTextStyeAppData.getContentText());
//
//
//            // 3. Set up main Intent for notification.
//            Intent mainIntent = new Intent(context, BigPictureSocialMainActivity.class);
//
//
//            // Gets a PendingIntent containing the entire back stack.
//            PendingIntent mainPendingIntent =
//                    PendingIntent.getActivity(
//                            context,
//                            0,
//                            mainIntent,
//                            PendingIntent.FLAG_UPDATE_CURRENT
//                    );
//
//            // 4. Build and issue the notification.
//
//            // Because we want this to be a new notification (not updating a previous notification), we
//            // create a new Builder. However, we don't need to update this notification later, so we
//            // will not need to set a global builder for access to the notification later.
//
//            final NotificationCompat.Builder notificationCompatBuilder =
//                    new NotificationCompat.Builder(context.getApplicationContext(), notificationChannelId);
//
//            GlobalNotificationBuilder.setNotificationCompatBuilderInstance(notificationCompatBuilder);
//
//            notificationCompatBuilder
//
//                    // BIG_TEXT_STYLE sets title and content for API 16+ (4.1 and after) when the
//                    // notification is expanded.
//                    .setStyle(bigTextStyle)
//
//                    // Title for API <16 (4.0 and below) devices and API 16+ (4.1 and after) when the
//                    // notification is collapsed.
//                    .setContentTitle(summaryBigTextStyeAppData.getContentTitle())
//
//                    // Content for API <24 (7.0 and below) devices and API 16+ (4.1 and after) when the
//                    // notification is collapsed.
//                    .setContentText(summaryBigTextStyeAppData.getContentText())
//                    .setSmallIcon(R.mipmap.ic_launcher)
//                    .setContentIntent(mainPendingIntent)
//                    .setDefaults(NotificationCompat.DEFAULT_ALL)
//                    // Set primary color (important for Wear 2.0 Notifications).
//                    .setColor(ContextCompat.getColor(context.getApplicationContext(), R.color.colorPrimary))
//
//                    // SIDE NOTE: Auto-bundling is enabled for 4 or more notifications on API 24+ (N+)
//                    // devices and all Wear devices. If you have more than one notification and
//                    // you prefer a different summary notification, set a group key and create a
//                    // summary notification via
//                    .setGroup(summaryBigTextStyeAppData.getGroupName())
//
//                    .setCategory(notificationData.getCategory())
//
//                    // Sets priority for 25 and below. For 26 and above, 'priority' is deprecated for
//                    // 'importance' which is set in the NotificationChannel. The integers representing
//                    // 'priority' are different from 'importance', so make sure you don't mix them.
//                    .setPriority(summaryBigTextStyeAppData.getPriority())
//
//                    // Sets lock-screen visibility for 25 and below. For 26 and above, lock screen
//                    // visibility is set in the NotificationChannel.
//                    .setVisibility(summaryBigTextStyeAppData.getChannelLockscreenVisibility())
//                    .setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_SUMMARY); // only summary notification makes noise.
//
//            //buildActions(context, notificationCompatBuilder, eachData);
//            Notification notification = notificationCompatBuilder.build();
//            notificationCompatArrayList.add(notification);
//
//
//            mNotificationManagerCompat.notify(eachData.getNotificationId(), notification);
//
//        }
//
//
//        Notification summaryNotification =
//                new NotificationCompat.Builder(context, notificationChannelId)
//                        .setContentTitle("Summary title")
//                        //set content text to support devices running API level < 24
//                        .setContentText("Two new messages")
//                        .setSmallIcon(R.mipmap.ic_launcher)
//                        //build summary info into InboxStyle template
//                        .setStyle(new NotificationCompat.InboxStyle()
//                                .addLine("people interested 1")
//                                .addLine("people interested 2")
//                                //.setBigContentTitle()
//                                .setSummaryText("Interest"))
//                        //specify which group this notification belongs to
//                        .setGroup(notificationData.getGroupName())
//                        //set this notification as the summary for the group
//                        .setGroupSummary(true)
//                        .build();
//
//
//        mNotificationManagerCompat.notify(notificationData.getSummaryNotificationId(), summaryNotification);
//
//
//    }


    private static void buildActions(Context context, NotificationCompat.Builder notificationCompatBuilder, NotificationData notificationData) {

        try {

            if (!notificationData.getActions().isEmpty()) {

                JSONArray jsonArray = new JSONArray(notificationData.getActions());
                for (int i = 0; i < jsonArray.length(); i++) {

                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String actionLabel = jsonObject.getString("label");
                    String actionUrl = jsonObject.getString("url");
                    Integer actionImage = R.mipmap.ic_launcher;
                    try {
                        actionImage = IMAGE_MAP.get(jsonObject.getString("action_image"));
                    } catch (Exception ignored) {

                    }


                    Intent actionIntent = new Intent(context, NotificationIntentService.class);
                    actionIntent.setAction(actionUrl);
                    actionIntent.putExtra(NOTIFICATION_ID, notificationData.getNotificationId());

                    PendingIntent actionPendingIntent = PendingIntent.getService(context, notificationData.getNotificationId(), actionIntent, 0);
                    NotificationCompat.Action notificationAction =
                            new NotificationCompat.Action.Builder(
                                    actionImage,
                                    actionLabel,
                                    actionPendingIntent)
                                    .build();
                    notificationCompatBuilder.addAction(notificationAction);

                }

            }
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
    }

    public static String createNotificationChannel(
            Context context,
            MockDatabase.MockNotificationData mockNotificationData) {

        // NotificationChannels are required for Notifications on O (API 26) and above.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            // The id of the channel.
            String channelId = mockNotificationData.getChannelId();

            // The user-visible name of the channel.
            CharSequence channelName = mockNotificationData.getChannelName();
            // The user-visible description of the channel.
            String channelDescription = mockNotificationData.getChannelDescription();
            int channelImportance = mockNotificationData.getChannelImportance();
            boolean channelEnableVibrate = mockNotificationData.isChannelEnableVibrate();
            int channelLockscreenVisibility =
                    mockNotificationData.getChannelLockscreenVisibility();

            // Initializes NotificationChannel.
            NotificationChannel notificationChannel =
                    new NotificationChannel(channelId, channelName, channelImportance);
            notificationChannel.setDescription(channelDescription);
            notificationChannel.enableVibration(channelEnableVibrate);
            notificationChannel.setLockscreenVisibility(channelLockscreenVisibility);

            // Adds NotificationChannel to system. Attempting to create an existing notification
            // channel with its original values performs no operation, so it's safe to perform the
            // below sequence.
            NotificationManager notificationManager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);

            return channelId;
        } else {
            // Returns null for pre-O (26) devices.
            return null;
        }
    }
}
