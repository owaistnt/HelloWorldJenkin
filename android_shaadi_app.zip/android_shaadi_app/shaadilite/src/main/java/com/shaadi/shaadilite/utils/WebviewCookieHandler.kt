package com.shaadi.shaadilite.utils

import android.os.Build
import android.util.Log
import android.webkit.CookieManager
import android.webkit.ValueCallback
import com.shaadi.shaadilite.BuildConfig
import java.net.URLDecoder


class WebviewCookieHandler {

    fun acceptCookies(){
        CookieManager.getInstance().setAcceptCookie(true)
    }
    fun setCookies(cookies: ArrayList<String>) {
        cookies.forEach {
            CookieManager.getInstance().setCookie(BuildConfig.SHAADI_LITE_COOKIE_URL, "${it} path=/")
        }
    }

    fun setCookie(cookie: String) {
            CookieManager.getInstance().setCookie(BuildConfig.SHAADI_LITE_COOKIE_URL, "${cookie} path=/")

    }

    fun getCookie(cookieName: String): String? {
        //Log.d("cookies", "get cookies ->> " + CookieManager.getInstance().getCookie(BuildConfig.SHAADI_LITE_COOKIE_URL))

        var cookieValue: String? = null
        val cookiesString = CookieManager.getInstance().getCookie(BuildConfig.SHAADI_LITE_COOKIE_URL)
        if (!cookiesString.isNullOrEmpty()) {
            cookiesString.splitIntoArray(";")
                    .filter { it.contains(cookieName) }
                    .map { it.splitIntoArray("=") }
                    .forEach { cookieValue = it[1] }
        }
        return cookieValue
    }

    fun printAllCookie()  {
        val cookiesString = CookieManager.getInstance().getCookie(BuildConfig.SHAADI_LITE_COOKIE_URL)
        if (!cookiesString.isNullOrEmpty()) {
            cookiesString.splitIntoArray(";")
                    .map { it.splitIntoArray("=") }
                    .forEach { it[1]
                    Log.d("cookies","${URLDecoder.decode(it[0], "UTF-8")} ->  ${URLDecoder.decode(it[1], "UTF-8")}")}
        }
    }

    fun clearCookies(callback: Callback? =null){
        val cookieManager = CookieManager.getInstance()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.removeAllCookies(object : ValueCallback<Boolean> {
                override fun onReceiveValue(aBoolean: Boolean?) {
                    if(callback!=null)
                        callback.cleared(aBoolean);
                    Log.d("cookies", "Cookie removed: " + aBoolean!!)
                }
            })
        } else {
            cookieManager.removeAllCookie()
            if(callback!=null)
                callback.cleared(true);
        }
    }

    private fun String.splitIntoArray(delimiter: String) =
            this.split(delimiter).dropLastWhile { it.isEmpty() }.toTypedArray()

    interface Callback{
        fun cleared(cleared:Boolean?)
    }

}

