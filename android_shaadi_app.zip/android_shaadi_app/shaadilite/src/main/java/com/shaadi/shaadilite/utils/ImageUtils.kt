package com.shaadi.shaadilite.utils

import android.graphics.*
import java.net.HttpURLConnection
import java.net.URL

object ImageUtils {
    fun getCircleBitmap(bitmap: Bitmap): Bitmap {
        val size = Math.min(bitmap.width, bitmap.height)
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val color = Color.RED
        val paint = Paint()
        val rect = Rect(0, 0, size, size)

        val rectF = RectF(rect)

        paint.isAntiAlias = true
        canvas.drawARGB(0, 0, 0, 0)
        paint.color = color
        canvas.drawOval(rectF, paint)

        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(bitmap, rect, rect, paint)

        bitmap.recycle()

        //120  is defined to fit image in notification - need to find a better solution but ws working on devices we tested
        return Bitmap.createScaledBitmap(output, 120, 120, false)
    }

    fun getBitmap(url: String): Bitmap? {

        //from web
        try {
            val imageUrl = URL(url)
            val conn = imageUrl.openConnection() as HttpURLConnection
            conn.connectTimeout = 30000
            conn.readTimeout = 30000
            conn.instanceFollowRedirects = true
            val `is` = conn.inputStream
            val myBitmap = BitmapFactory.decodeStream(`is`)
            return getCircleBitmap(myBitmap)
        } catch (ex: Exception) {
            ex.printStackTrace()
            return null
        }

    }
}