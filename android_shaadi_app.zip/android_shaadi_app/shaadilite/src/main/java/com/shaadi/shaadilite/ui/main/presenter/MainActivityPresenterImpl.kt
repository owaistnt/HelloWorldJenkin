/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.main.presenter

import android.net.Uri
import com.shaadi.shaadilite.BuildConfig
import com.shaadi.shaadilite.core.interactors.EventInteractorImpl
import com.shaadi.shaadilite.core.usecases.EventUsecases
import com.shaadi.shaadilite.core.usecases.TokenGenerated
import com.shaadi.shaadilite.core.usecases.TrackLogin
import com.shaadi.shaadilite.core.usecases.TrackLogout
import com.shaadi.shaadilite.data.network.RetrofitApiHelperImpl
import com.shaadi.shaadilite.data.preferences.AppPreferenceHelper
import com.shaadi.shaadilite.ui.base.BasePresenterImpl
import com.shaadi.shaadilite.ui.main.model.IMainActivityInteractor
import com.shaadi.shaadilite.ui.main.model.UserData
import com.shaadi.shaadilite.ui.main.view.IMainActivityView


class MainActivityPresenterImpl<V : IMainActivityView, I : IMainActivityInteractor>(mvpInteractor: I) : BasePresenterImpl<V, I>(mvpInteractor), IMainActivityPresenter<V, I> {


    private lateinit var webviewHelper: WebViewUrlHelper
    private lateinit var eventUsecases: EventUsecases;

    override fun processPageLoading(uri: String?, isDeepLink: Boolean, deepLinkUri: String?) {
        if (isDeepLink) {
            mvpView?.startLoadingUrl(replaceDomainToShaadi(deepLinkUri!!))
        } else if (!uri.isNullOrEmpty()) {
            mvpView?.startLoadingUrl(uri)
        } else
            this.mvpView?.startPageLoading()


    }

    override fun onAttach(mvpView: V) {
        super.onAttach(mvpView)
        eventUsecases = EventUsecases(EventInteractorImpl(AppPreferenceHelper.getInstance(), RetrofitApiHelperImpl()))
        webviewHelper = WebViewUrlHelper()

        startNotificationTrackingIfValidUser();
    }

    private fun startNotificationTrackingIfValidUser() {
        if (interactor?.isLoggedInMember() == true) {
            this.mvpView?.startNotificationStateChangeListenerService()
        }
    }

    override fun handleWebUrl(url: String, callback: WebViewUrlHelper.Callback) {
        if (webviewHelper.isExternalLinkUrl(url)) {
            callback.loadExternalUrl()
        } else if (webviewHelper.isSignInScreenUrl(url)) {
            interactor?.let { callback.loadUrl(it.loginApi()) }
        } else if (webviewHelper.isSignUpScreenUrl(url)) {
            interactor?.let { callback.loadUrl(it.regApi()) }
        } else {
            callback.loadUrl()
        }
    }

    override fun onUserLoggedIn(userData: UserData) {
        if (userData.isValid) { //check if both memberlogin & abc are not empty

            interactor?.apply {
                if (isTokenChangedOrEmpty(userData)) { //check if token is empty or changed
                    saveUserData(userData)
                    eventUsecases.trackEvent(TrackLogin(source = ""))

                    eventUsecases.trackEvent(TokenGenerated(source = ""))
                    markUserLoggedInStatus(true)
                }
            }
            startNotificationTrackingIfValidUser();
        }
    }

    override fun onUserLoggedOut() {
        interactor?.apply {
            if (!getMemberLoginId().isNullOrEmpty())
                eventUsecases.trackEvent(TrackLogout(source = ""))

            markUserLoggedInStatus(false)
            saveUserData(UserData(null, null))
            clearCachedData()
        }

        mvpView?.apply {
            if (!clearSlangIfMainApp())
                setDefaultSlang()
            reloadPage()
        }
    }

    override fun isLoggedInMember(): Boolean {
        return interactor?.isLoggedInMember() == true
    }

    /*THis is a hack where any deeplinkin happening will be replaced by shaadi.com domain as
    there is routing done in lite from shaadi based on app */
    private fun replaceDomainToShaadi(uri: String): String {
        val urlDeepLinked = Uri.parse(uri)
        val urlShaadi = Uri.parse(BuildConfig.SHAADI_LITE_URL)
        return if (urlShaadi.host != urlDeepLinked.host) {
            val builder = Uri.Builder()
            builder.scheme(urlDeepLinked.scheme)
                    .authority(urlShaadi.host)
            for (i in 0 until urlDeepLinked.pathSegments.size) {
                builder.appendPath(urlDeepLinked.pathSegments[i])
            }
            val query = urlDeepLinked.queryParameterNames
            for (i in query) {
                builder.appendQueryParameter(i, urlDeepLinked.getQueryParameter(i))
            }
            val newUrl = builder.build().toString()
            newUrl
        } else
            uri
    }
}
