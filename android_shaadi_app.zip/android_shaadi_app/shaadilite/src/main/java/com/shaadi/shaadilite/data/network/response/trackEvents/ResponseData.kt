package com.shaadi.shaadilite.data.network.response.trackEvents

import com.shaadi.shaadilite.data.network.response.Error

data class ResponseData(
        val data: HashMap<String,TrackLogin>,
        val error: Error
)