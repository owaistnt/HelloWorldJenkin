/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.splash.view

import com.shaadi.shaadilite.ui.base.IBaseView
import com.shaadi.shaadilite.ui.splash.SplashScreenActivity

interface ISplashActivityView :IBaseView{
    fun openMainScreen(loginUrl:String )
    fun openLoginScreen()
    fun getInitialData(data:SplashScreenActivity.Result)
}