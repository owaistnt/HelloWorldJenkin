/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.login.model

import com.shaadi.shaadilite.ui.base.IBaseInteractor

interface ILoginActivityInteractor :IBaseInteractor {
    fun loginApi():String
    fun regApi():String
    fun getCookies():ArrayList<String>

}
