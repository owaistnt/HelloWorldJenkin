/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite

import android.app.Application
import android.os.StrictMode
import android.support.multidex.MultiDexApplication
import android.util.Log
import com.appsflyer.AppsFlyerConversionListener
import com.appsflyer.AppsFlyerLib
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.messaging.FirebaseMessaging
import com.shaadi.shaadilite.data.preferences.AppPreferenceHelper
import com.shaadi.shaadilite.utils.FirebaseTracking

class ShaadiLiteApplication : MultiDexApplication() {

    val APPSFLYERKEY = "fyQ93e6XRZfVpyhiCrZVJ8"

    override fun onCreate() {
        super.onCreate()
        AppPreferenceHelper.init(this);
        FirebaseTracking.init(this)
        if (BuildConfig.DEBUG) {
            setThreadPolicy()
            setVmPolicy()
        }
        startAppflyer()



    }

    private fun setThreadPolicy() {
        StrictMode.setThreadPolicy(StrictMode.ThreadPolicy.Builder()
                .detectDiskReads()
                .detectDiskWrites()
                .detectNetwork()
                .penaltyLog()
                .build())
    }

    private fun setVmPolicy() {
        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder()
                .detectLeakedSqlLiteObjects()
                .detectLeakedClosableObjects()
                .penaltyLog()
                .penaltyDeath()
                .build())

    }


    private fun startAppflyer() {
        val conversionDataListener = object : AppsFlyerConversionListener {
            override fun onInstallConversionDataLoaded(conversionData: Map<String, String>) {
                // check key for source of installation
                for (attrName in conversionData.keys) {
                    Log.d(AppsFlyerLib.LOG_TAG, "attribute: " + attrName + " = " +
                            conversionData[attrName])
                }
            }

            override fun onInstallConversionFailure(errorMessage: String) {
                Log.d(AppsFlyerLib.LOG_TAG, "error getting conversion data: $errorMessage")

            }

            override fun onAppOpenAttribution(map: Map<String, String>) {

            }

            override fun onAttributionFailure(errorMessage: String) {
                Log.d(AppsFlyerLib.LOG_TAG, "error onAttributionFailure : $errorMessage")

            }
        }

        AppsFlyerLib.getInstance().init(APPSFLYERKEY, conversionDataListener, applicationContext)
        AppsFlyerLib.getInstance().enableUninstallTracking(getString(R.string.gcm_defaultSenderId))
        if(BuildConfig.DEBUG) {
            AppsFlyerLib.getInstance().setDebugLog(true)
            FirebaseMessaging.getInstance().subscribeToTopic("lite_test")
        }
        AppsFlyerLib.getInstance().startTracking(this@ShaadiLiteApplication)
    }

}
