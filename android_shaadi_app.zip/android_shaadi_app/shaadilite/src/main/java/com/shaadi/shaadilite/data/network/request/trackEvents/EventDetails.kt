package com.shaadi.shaadilite.data.network.request.trackEvents

import android.os.Build
import com.shaadi.shaadilite.BuildConfig
import java.util.*

class EventDetails {
    lateinit var event_name: String
    val event_timestamp: Long=Date().time
    val platform: String=BuildConfig.PLATFORM
    lateinit var memberlogin: String
    val device:String= Build.MANUFACTURER
    lateinit var event_info: EventInfo
}