/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.data.preferences

import android.content.Context
import android.content.SharedPreferences
import android.text.TextUtils
import com.google.gson.Gson

/**
 * Created by munnag on 20/12/17.
 */
class AppPreferenceHelper private constructor(context: Context) : IPreferenceHelper {
    private val mPrefs: SharedPreferences

    init {
        mPrefs = context.getSharedPreferences(PREFERENCE_FILE, Context.MODE_PRIVATE)
    }

    companion object {
        private val PREF_KEY_GAID = "PREF_KEY_GAID"
        private val PREF_KEY_MEMBER_ID = "PREF_KEY_MEMBER_ID"
        private val PREF_KEY_FCM = "PREF_KEY_FCM"
        private val PREF_KEY_ABC = "PREF_KEY_ABC"
        private val PREF_KEY_IS_LOGGED_IN = "PREF_KEY_IS_LOGGED_IN"
        private val PREF_KEY_LAST_NOTIFICATION_MD5SUM = "PREF_KEY_LAST_NOTIFICATION_MD5SUM"
        private val PREFERENCE_FILE = "shaadi_lite.pref"
        private var appPreferenceHelper: AppPreferenceHelper? = null

        @JvmStatic
        fun init(context: Context) {
            if (appPreferenceHelper == null)
                appPreferenceHelper = AppPreferenceHelper(context)
        }

        @JvmStatic
        fun getInstance(): AppPreferenceHelper {
            return appPreferenceHelper as AppPreferenceHelper
        }
    }

    override var gaid: String?
        get() = mPrefs.getString(PREF_KEY_GAID, null)
        set(value) {
            mPrefs.edit().putString(PREF_KEY_GAID, value).apply()
        }

    override var fcmToken: String?
        get() = mPrefs.getString(PREF_KEY_FCM, null)
        set(value) {
            mPrefs.edit().putString(PREF_KEY_FCM, value).apply()
        }

    override var isLoggedIn: Boolean
        get() = mPrefs.getBoolean(PREF_KEY_IS_LOGGED_IN, false)
        set(value) {
            mPrefs.edit().putBoolean(PREF_KEY_IS_LOGGED_IN, value).apply()
        }

    override var memberId: String?
        get() = mPrefs.getString(PREF_KEY_MEMBER_ID, null)
        set(value) {
            mPrefs.edit().putString(PREF_KEY_MEMBER_ID, value).apply()
        }

    override var notificationMd5Sum: String?
        get() = mPrefs.getString(PREF_KEY_LAST_NOTIFICATION_MD5SUM, "")
        set(value) {
            mPrefs.edit().putString(PREF_KEY_LAST_NOTIFICATION_MD5SUM, value).apply()

        }

    override var abcToken: String?
        get() = mPrefs.getString(PREF_KEY_ABC, "")
        set(value) {
            mPrefs.edit().putString(PREF_KEY_ABC, value).apply()
        }

}
