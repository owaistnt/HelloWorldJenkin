/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.base

/**
 * Every presenter in the app must either implement this interface or extend BasePresenterImpl
 * indicating the IBaseView type that wants to be attached with.
 */
interface IBasePresenter<V : IBaseView, I : IBaseInteractor> {

    var mvpView: V?

    var interactor: I?

    val isViewAttached: Boolean

    fun onAttach(mvpView: V)

    fun onDetach()

    @Throws(BasePresenterImpl.MvpViewNotAttachedException::class)
    fun checkViewAttached()


    fun setUserAsLoggedOut()
}
