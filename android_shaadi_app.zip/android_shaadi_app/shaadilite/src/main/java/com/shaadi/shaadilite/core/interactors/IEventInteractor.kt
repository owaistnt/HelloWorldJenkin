package com.shaadi.shaadilite.core.interactors

import com.shaadi.shaadilite.core.usecases.EventTypes
import com.shaadi.shaadilite.core.usecases.EventUsecases
import com.shaadi.shaadilite.data.network.request.trackEvents.EventBody
import com.shaadi.shaadilite.data.network.response.trackEvents.ResponseData
import com.shaadi.shaadilite.ui.base.IBaseInteractor

interface IEventInteractor:IBaseInteractor {
    fun trackEventOnServer(headerMap: Map<String, String>, rawReqModel: EventBody, icallback: EventUsecases.ICallback?)
    fun trackEventOnThirdParty(eventTypes: EventTypes)
    fun getMemberLogin():String?
    fun getDeviceId():String?
    fun getFcmToken():String?
}