package com.shaadi.shaadilite.data.network.request.trackEvents

class ChannelInfo{
    lateinit var priority:String
}