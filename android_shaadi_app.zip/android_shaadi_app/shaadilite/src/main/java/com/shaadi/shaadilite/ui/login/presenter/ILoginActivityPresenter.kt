/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.login.presenter

import com.shaadi.shaadilite.ui.base.IBasePresenter
import com.shaadi.shaadilite.ui.login.model.ILoginActivityInteractor
import com.shaadi.shaadilite.ui.login.view.ILoginActivityView

interface ILoginActivityPresenter<V : ILoginActivityView, I : ILoginActivityInteractor> : IBasePresenter<V, I>{
    fun onLoginButtonClick()
    fun onRegButtonClick()
}