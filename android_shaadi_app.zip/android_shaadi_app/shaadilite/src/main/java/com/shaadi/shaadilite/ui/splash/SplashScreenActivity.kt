/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.splash

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import com.google.android.gms.tasks.Tasks
import com.google.firebase.iid.FirebaseInstanceId
import com.shaadi.shaadilite.data.network.RetrofitApiHelperImpl
import com.shaadi.shaadilite.data.preferences.AppPreferenceHelper
import com.shaadi.shaadilite.ui.base.BaseActivity
import com.shaadi.shaadilite.ui.login.LoginActivity
import com.shaadi.shaadilite.ui.main.MainActivity
import com.shaadi.shaadilite.ui.splash.model.ISplashActivityInteractor
import com.shaadi.shaadilite.ui.splash.model.SplashActivityInteractorImpl
import com.shaadi.shaadilite.ui.splash.presenter.ISplashActivityPresenter
import com.shaadi.shaadilite.ui.splash.presenter.SplashActivityPresenterImpl
import com.shaadi.shaadilite.ui.splash.view.ISplashActivityView
import com.shaadi.shaadilite.utils.Utils
import java.util.concurrent.Callable


class SplashScreenActivity : BaseActivity(), ISplashActivityView {

    lateinit var mPresenter: ISplashActivityPresenter<ISplashActivityView, ISplashActivityInteractor>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setUp()
    }

    override fun setUp() {
        mPresenter = SplashActivityPresenterImpl(SplashActivityInteractorImpl(AppPreferenceHelper.getInstance(), RetrofitApiHelperImpl()))
        mPresenter.onAttach(this)
    }

    override fun openMainScreen(loginUrl: String) {
        val intent = Intent(this@SplashScreenActivity, MainActivity::class.java).apply {
            putExtra(MainActivity.KEY_LANDING_URL, loginUrl)
        }
        startActivity(intent)
    }

    override fun openLoginScreen() {
        val intent = Intent(this@SplashScreenActivity, LoginActivity::class.java)
        startActivity(intent)
    }

    override fun getInitialData(data: Result) {
        Tasks.call(
                AsyncTask.THREAD_POOL_EXECUTOR,
                Callable<Result> {

                    if (data.gaid.isNullOrEmpty())
                        data.gaid = Utils.getGAID(applicationContext)

                    if (data.fcmToken.isNullOrEmpty())
                        data.fcmToken = Tasks.await(FirebaseInstanceId.getInstance().instanceId).token

                    data

                }).addOnSuccessListener { result ->
            mPresenter.updateInitialData(result)
        }

    }

    override fun onDestroy() {
        mPresenter.onDetach()
        super.onDestroy()

    }

    data class Result(var gaid: String?, var fcmToken: String?)

}
