package com.shaadi.shaadilite.data.network.response.trackEvents

data class Data(
        val track_login: TrackLogin
)