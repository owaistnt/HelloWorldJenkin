/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.base

import android.app.ProgressDialog
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Toast
import com.shaadi.shaadilite.utils.Utils


 abstract class BaseActivity: AppCompatActivity(),IBaseView {

     private var mProgressDialog: ProgressDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }
    abstract fun setUp()


    override fun showLoading() {
        mProgressDialog =Utils.showLoadingDialog(this)
    }

    override fun hideLoading() {
        mProgressDialog?.let {
            if (it.isShowing){
                it.cancel()
            }
        }
    }

    override fun openActivityOnTokenExpire() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onError(resId: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

     override val isNetworkConnected: Boolean
         get() = TODO("not implemented") //To change initializer of created properties use File | Settings | File Templates.

     override fun onError(message: String) {
         TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
     }

     override fun showMessage(message: String) {
         Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
     }

     override fun showMessage(resId: Int) {
         TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
     }

     override fun hideKeyboard() {
         TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
     }

}