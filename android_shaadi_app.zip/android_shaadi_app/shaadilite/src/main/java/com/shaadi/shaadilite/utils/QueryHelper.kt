package com.shaadi.shaadilite.utils

import com.shaadi.shaadilite.contants.QueryKeyConstants
import com.shaadi.shaadilite.contants.QueryValueConstants
import com.shaadi.shaadilite.data.preferences.IPreferenceHelper

object QueryHelper {

    fun WebCallDefaultQueryParams(appPreferenceHelper: IPreferenceHelper): String {
        return buildNonLoggedInDefaultQueryParams(appPreferenceHelper).build()
    }

    private fun buildNonLoggedInDefaultQueryParams(appPreferenceHelper: IPreferenceHelper): QueryBuilder {
        val queryHandler = QueryBuilder().apply {
            addMap(QueryKeyConstants.KEY_REG_MOD, QueryValueConstants.VALUE_REG_MOD)
            addMap(QueryKeyConstants.KEY_OS, QueryValueConstants.VALUE_OS)
            addMap(QueryKeyConstants.KEY_DEVICE_ID, appPreferenceHelper.gaid!!)
            addMap(QueryKeyConstants.KEY_APP_VERSION, QueryValueConstants.VALUE_APP_VERSION)
            addMap(QueryKeyConstants.KEY_MANUFACTURER, QueryValueConstants.VALUE_MANUFACTURER)
            addMap(QueryKeyConstants.KEY_MODEL, QueryValueConstants.VALUE_MODEL)
        }

        return queryHandler
    }

    fun buildUpdateLastLoginQuery(appPreferenceHelper: IPreferenceHelper): String {
        val queryHandler = buildLoggedInDefaultQueryParams(appPreferenceHelper).apply {
            addMap(QueryKeyConstants.KEY_APPLAUNCH, QueryValueConstants.VALUE_APP_LAUNCH)
        }
        return queryHandler.build()
    }

    private fun buildLoggedInDefaultQueryParams(appPreferenceHelper: IPreferenceHelper): QueryBuilder {
        val queryHandler = buildNonLoggedInDefaultQueryParams(appPreferenceHelper).apply {
//            addMap(QueryKeyConstants.KEY_ABC, appPreferenceHelper.abcToken?:"")
//            addMap(QueryKeyConstants.KEY_ML, appPreferenceHelper.memberId?:"")
            addMap(QueryKeyConstants.KEY_FORMAT, QueryValueConstants.VALUE_RESPONSE_FORMAT)
        }
        return queryHandler
    }

    fun tokenQueryBuilder(appPreferenceHelper: IPreferenceHelper): String {
        val queryHandler = buildLoggedInDefaultQueryParams(appPreferenceHelper)
        return queryHandler.build()
    }

}