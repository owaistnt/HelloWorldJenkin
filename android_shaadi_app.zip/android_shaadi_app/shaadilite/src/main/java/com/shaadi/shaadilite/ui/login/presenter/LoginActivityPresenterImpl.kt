/*
 * Copyright (c) 2018
 * PEOPLE INTERACTIVE INDIA PRIVATE LIMITED,  All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 *  Proprietary and confidential
 */

package com.shaadi.shaadilite.ui.login.presenter

import com.shaadi.shaadilite.ui.base.BasePresenterImpl
import com.shaadi.shaadilite.ui.login.model.ILoginActivityInteractor
import com.shaadi.shaadilite.ui.login.view.ILoginActivityView


class LoginActivityPresenterImpl<V : ILoginActivityView, I : ILoginActivityInteractor>(mvpInteractor: I) : BasePresenterImpl<V, I>(mvpInteractor), ILoginActivityPresenter<V, I> {

    override fun onAttach(mvpView: V) {
        super.onAttach(mvpView)
        this.interactor?.let {
            this.mvpView?.setCookies(it.getCookies())
        }
    }

    override fun onRegButtonClick() {
        interactor?.regApi()?.let { this.mvpView?.openRegistrationScreen(it) }
    }

    override fun onLoginButtonClick() {
        this.interactor?.loginApi()?.let { this.mvpView?.openLoginScreen(it) }
    }
}
