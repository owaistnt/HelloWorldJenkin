package com.shaadi.shaadilite.utils

import com.shaadi.shaadilite.BuildConfig
import com.shaadi.shaadilite.data.preferences.AppPreferenceHelper

object ApiUtils {
    val HEADER_CONTENT_TYPE = "Content-Type"
    val HEADER_X_ACCESS_TOKEN = "X-access-token"
    val HEADER_X_APP_KEY = "X-app-key"

    fun getDefaultHeader(): HashMap<String, String> {
        val headerMap = HashMap<String, String>().apply {
            put(HEADER_CONTENT_TYPE, "application/json")
            put(HEADER_X_ACCESS_TOKEN, AppPreferenceHelper.getInstance().abcToken!!)
            put(HEADER_X_APP_KEY, BuildConfig.X_APP_KEY)
        }
        return headerMap
    }
}