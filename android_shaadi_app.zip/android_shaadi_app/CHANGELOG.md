# Change Log
All notable changes to shaadi.com app project will be documented in this file.
The format is based on [Keep a Changelog](http://keepachangelog.com/) 

# Notation to be followed
## Added
### Changed
### Fixed
### Removed
### Cancelled For Live

##[5.12.1]  10% 13/05/2019
###Added
1.Premium Info card in profile page with A/B where A/B rules are being executed from the backend 
2.Support for annual income correction stoppage 
3.App launch event - a new event has been added which will be called on every launch of our app and the same will be captured and consumed by falcon for notification management 
##Changed
1.Achievement login screen code cleanup & refactoring using kotlin & New Architecture components 
###Fixed
1.Fabric bug fixes - profile page bundle size exception
2.Fabric issue fix - Contact detail all response being handled properly
3.Fabric - shaired element crash fix for inbox wuick response stopage

##[5.12.0]  10% 25/04/2019
###Added
1.New payment page 1 with feature

##[5.11.3] 5% 18-04-2019 10% 19-04-2019
###Added
1.Number verification migration to new aac component
2.Profile End state for new matches listing

##[5.11.2]  5% 6-04-2019
###Added
1.Whatsapp optin notification
2.Add photo button in photo upload notification

##[5.11.1] 5% 20-03-2019 30% 50% 25-03-2019 100% 27-03-2019
1.Fabric bug fixes for release 5.11.0
2.Search country and district not be send on basic search fix

##[5.11.0] 5% 18-03-2019
###Added
1.New profile page migration on Go
2.Removed surpise me

## Community Apps [5.10.0] 10% 5-03-2019 
##[5.10.0] 10% 4-03-2019 90% 5-03-2019 100% 6-03-2019
###Added
1.Sms retreiver api migration
2.Whatsapp UI changes
3.Verification link on complete your profile page in shaadi dashboard
###Changed
1.Loging changed from http to https
###Fixes
1.Chat both party pay curtain fix
2.Shaadi care check/uncheck case handling
3.Fabric fixes on AdvanceSearchfragment


##[5.9.1] 10% 13-02-2019
###Added
1.UPI intent
2.Number based login

##[5.9.0] 5% 07-02-2019
###Added
1.Advance Search
###Changed
1.Payment for order id in sync call

##[5.8.12] 10% 26-01-2019 30% 26-01-2019 50% 28-01-2019 99% 28-01-2019
###Fixed
1.OPPO f1 crash fix on forgoet password

##[5.8.11] 10% 23-01-2019
###Added
1.Whatsapp opt in setting page
2.In case of certain response in forgot password show the sign up button
###Changes
1.Removal of deleted,blocked and hidden profile  from qucik inbox response
####
1.Resolution fix


##[5.8.10] 10% 17-01-2019 30% 18-01-2019 
###Added
1.Whatsapp opt in
2.Forgot password
3.Inbox c case
4.Snowplow tracking for delivary and click
5.Opt in for shaadi care handling from server
###Removed
1.Facebook verification for both party pay removed
###Fixed
1.Payment source tracking


##[5.8.9] 10% 28-12-2018   30% 31-12-2018 60% 2-01-2019 99% 4-01-2019
####Fix
1. Fix for new tracking api call for sending fcm token for existing users was being sent empty 

##[5.8.8] 10% 27-12-2018  
####Added
1. Csat rating on 4& 5 when user clicks cancel
2. Inbox quick Response (A/B) - vid 1.0 
3. Call SOA API on Login, Logout, device token change and notification settings changed for Multi device support.


##[5.8.7] 5% 13-12-2018 30% 15-12-2018 50% 17-12-2018  70% 18-12-2018 99% 20-12-2018
###Added
1.Fix for Payment page Case A where users were being charged twice
2.Handling of accept on daily recommendation

##[5.8.6] 10% 30-11-2018
###Added
1.AB for accept celebration
2.For premium csat we need to take uer to play store who is triying to rate 4&5 
3.Validation for AMEX card to show invalid on client end

##[5.8.5] 10% 30-11-2018
###Fixed
1.Fabric bug where it was crashing on payment due to lateinit

##[5.8.4] 5% 29-11-2018
###Added
1.New Payment Page 1 case B added
2.Tracking for registration creation and ROG
2.Save draft

##[5.8.3] 5% 13-11-2018 100% 28-11-2018 community app 29-11-2018
###Changes
1.Removed aadhar From login screen as product requirement
2.Shortlist card changes from small to matches like card
###Added
1.Profile completion card tracking in App
###Fixed
1.IllegleStateException which was happeing on oreo and bove fix

##[5.8.2] 5% 13-11-2018 30% 14-11-2018 50% 14-11-2018
###Fixed
1.Binder crash cause of Trasaction to large

##[5.8.1] 5% 12-11-2018
### Added
1. Oreo Compatibility
2. Appsflyer version upgraded to 4.8.17
3. Inbox Filter UI revert

##[5.8.0] 
###Added
1.Oreo Compatiblity

##[5.7.5] 
###Added
1.Notification landling of url in App
2.Two way pay should not be applicable if the message received by the user is a premium user
###Fixed
1.Unblock code instead report misuse

##[5.7.4] 10% 25-10-2018 30% 26-10-2018
###Added
1.Photo image upload location tracking
###Changes
1.Inbox api call optimization
2.Changed upgrade not to renew now
###Fixed
1.Children spelling fix -https://shaadi.atlassian.net/browse/ANDROID-3563
2.Refine not happeing on matches fix- https://shaadi.atlassian.net/browse/ANDROID-3559
3.juspay Fix for the API cancellation on progress bar dismiss or backpress
4.Oneplus coachmark issue on inbox fix

##[5.7.3] 30% 10-10-2018
###Fixed
1.Fabric crash fixes
   - chat & main app landing
###Added
##[5.7.2] 10% 09-10-2018
###Added
1.Netbanking with Juspay express and UPI refactor
2.Firebase performance sdk
3.A/B on PP1 for SKU card state
4.Added snowplow tracking for card completion
5.Email update on setting page
6.New Inbox filter UI
###Changes
1.Updated chat profile api (GOLANG Chat profile API)
###Fixed
1.ENGAGEMENT-2510, Msg now displayed based on error code received from lookup-shortcode api
2.No tail issue in chat for only one message
3.ANDROID-3554 -- Removed current miniprofile from UI since we are already adding it to undo stack
4.https://shaadi.atlassian.net/browse/SHAADICRM-1971
5.https://shaadi.atlassian.net/browse/ANDROID-3557 - Profile card removed on clicking write message in matches and click back from chat window
6.Fabric top crash http://crashes.to/s/28f67c46029 - crash on recent visitors list
7.Thankyou page after payment page reload
8.FABRIC 34429 - ImageDetailFragment.kt lateinit property mPager has not been initialized on profile and user album screen

##[5.7.1]  10% 28-09-2018
###Added
1.juspay express for debit/creadit card
###changes
1.Resent visitors listing clubing of viewed/unviewed

##[5.7.0]  10% 20-09-2018 30% 21-09-2018 50% 24-09-2018 100% 25-09-2018 
###Added
1.Landing female user to inbox on new interest - A/B
2.Signature Sku 
3.Event tracking triggering done from server for appsflyer
###Changed
1.Moved shortlist matches  from recently viewed carousal listing to Matches top nav
2.Removed old nineloid library and updated with crisbane code for Photo view
3.Order of top tab is changed
4.Image size for matches and profile changed from 750x1004 too 450x600
###Fixed
1.You and me removal of > sign
2.White bar on profile page removal

##[5.6.8] 10%  3-09-2018 30% 4-09-2018 50%  5-09-2018 100% 10-09-2018
###Fixed
1.Fabric fix - inbox request geting crashed so added logical check as we were not able to generate
2.FAbric fix - complete profile on premium listing back button not working on back press fix

##[5.6.7] 5%  31-08-2018
###Added
1.Profile completion cards (Employers and colleges details)
2.App sniffing 
3.Inbox new filters (Expiring soon and Expiring soon)
###Removed
1.New Inbox Api consumption
2.Hard coded string migration to resource file. (standard approach to support multilingual App later on when decided in Android )
3.Removal of CTA A/B code for A case since we are now 100% with B case thats single CTA. (Tech backlog)
4.Removal of payment A/B code for A case since now we are 100% on New payment page 2.(Tech backlog)

##[5.6.6] 10% 20-08-2018 30% 21-08-2018 50% 22-08-2018 100% 23-08-2018
###Added
1.Similar matches on Profile page
2.Premium carousal on matches
3.Signature SKU - (Free member can see platinum plus members no) - Onboarding SKU stoppage
###Fixes
1.Horoscope not being save fixed- state was not being saved
2.Count mismatch fixed on carousel listing - we were showing total count insted we need to show the unviewed count
3.Fabric crash on dashbord image being null fixed - logical we were not able to generate

##[5.6.5] 10% 17-07-2018 50% 18-07-2018 100% 23-07-2018 100% 26-07-2018
###Added
1.Contact detail in profile page
2.Profile complition add photo
###Fixes
1.Fabric crash fixes
  crash on Carousel of featured list logic changes
2.Photo request on matches listing was not happeing - copy past issue
3.Most Preferred matches landing loader issue fix while registration

##[5.6.4] 10% 02-07-2018 50% 03-07-2018 100% 04-07-2018
###Added
1.Similar matches on matches listing
2.App indexing for seo
3.juspay for debit/credit and netbanking
###Changes
1. SOA search api empty case handling
2. Chat grouping
3. Added logic to show Monetization of accept once in 24 hours
4. Monetization of accept design changes
###Removed
1.Payment page 2 A case code
###Fixes
1.Accept listing empty occupation case fix
2.Fabric logical check

##[5.6.3] 10% 19-06-2018 50% 20-06-2018
###Changes
1.Removed Monetization of accept banner for free and premium members 
2.Migrated inbox listing to read from DB instead directly adding to the list - index mismatch fix


##[5.6.2] 10% 11-06-2018
###Changes
1. Adhaar Verification prompt from MyShaadi Screen
2. Removed Camera and Hardware for camera permissions from Manifest.

## [5.6.1] 10% 05-06-2018 90% 06-06-2018 50% 07-06-2018(Morning ) 100% 07-06-2018 (Night)
###Fixed
1.Inbox listing not being loaded when user comes back from profile fix.
###Changes
1.Added back count in refine tab in inbox and accept listing

## [5.6.0] 10% 31-05-2018
###Changes
1.Image optimization - reduction in app size to 2MB
2.Online members in migration to MVP
3.App setting verification consent
###Fixed
1.Deleted not happening for profile image fix

## [5.5.10] 10% 24-05-2018 30% 25-05-2018 100% 28-05-2018
###Added
1. Previous & Next buttons in Full Profile Views in Android. 
2. Netbanking payment fix on Kitkat OS.
3. Auto move enabled for other CTAs except on free Connect

## [5.5.9] 10% 21-05-2018
###Added
1.Self Verification - (Aadhar)
2.Inbox Premium carousel
3.Monetization of accept for premium members
4.A floating button in the buddy list, which will take the user to the top of the buddy list

## [5.5.8]  10% 11-05-2018 20% 12-05-2018 50% 12-05-2018 100% 13-05-2015 community app 14-05-2018
###Added
1.Single CTA case handling

## [5.5.7]  10% 07-05-2018 20% 08-05-2018 50% 9-05-2018  100% 10-05-2018
###
1.FABRIC fix - device id 101 case missing
2.Fixes for release 5.5.6

## [5.5.6]  10% 03-05-2018
###Added
1.Onboarding stoppage
2.UPI
###Changes
1.Splash screen images changed – added gradient
2.Added aadhar icon on splash screen
3.Changed aadhar icon on profile and matches page
4.Appflyer upgraded library and removed imei tracking as said by appsflyer team
5.Upgraded Evernote job scheduler which is used for chat -
6.Letter case changes from sign up and sign in free on login and splash page (Change all capital letters to lower case except the first one).
7.Removal of imei collection of data as device id and using instance id or uuid generator as a unique identifier.
###Fixed
1.Logical checks for mobile country – offline order
2.My photo empty case - Logical null checks

## [5.5.5] 10% 23-04-2018 [20% 50% 24-04-2018] 100% 25-04-2018
###Added
1.WhatsApp in View Contact detail page for premium members-( B Bucket users only) and upgrade message UI changes on the Private chat window.
2.Animation on Monetization of accept  page

## [5.5.4] 10% 16-04-2018  20% 17-04-2018 50% 18-04-2018 community app 24-03-2018 100%
###Fixed
1.Fabric fixes for release 5.5.3
2.External URL landing fix

## [5.5.3] 10% 12-04-2018  
###Fixed
1.Facebook thumbnail photo import issue fixed
###Added
1.The free to free messaging should be handled for both party pay cases as well.
2.Otp in payment page 2-Cash payment/pickup,payment at bank,Shaadi center
3.Monetization of accepts
###Changes
1.Chat UI changes & Today text in chat

###Added
1.Free to free support for Both party pay	
## [5.5.2] 20% 3-04-2018  50% 04-04-2018 100% 04-04-2018
###Fixed
1.Fabric fixes - logical check
2.payment page debit card validation fix
3.payment page 2 view visiblity fix

## [5.5.1] 5% 28-03-2018 10% 29-03-2018 20% 30-03-2018
###Fixed
1.Fabric bug fixes

## [5.5.0] 5% 27-03-2018 
###Added
1.Entire Inbox Revamp with new card UI
2.MyPhoto page 1 revamp with a new design
3.A free/lapsed user cannot send interest to a listing in New Matches (0-15d)
###Changes
1.GCM to FCM migration

## [5.4.2] 30% 21-03-2018 50% 22-03-2018  100% 22-03-2018
###Fixed
1.Added free to free chat logic which was reverted due to branch taken from old source
## [5.4.1] 10% 16-03-2018 20% 16-03-2018 50% 17-03-2018
###Fixed
1.DR fabric crash fix - not able to generate logical check

## [5.4.0] 10% 15-03-2018
###Added
1.Verification on matches & Profile page - Aadhar verification
2.Payment page 2 revamp
3.Viewed unviewed
###Changes
1.Show only relevant profile information in the chat window
2.Free user will not be able to chat with another free user even if conversation history exists
3.Improved photo quality at all places where we have circular photos in chat
4.User will be able to see members whom they have sent interest to and shortlisted matches under my matches section of active buddy list
5.Added token refresh logic from server- currently kept at 24hrs

## [5.3.13] 100% 14-03-2018
###Changed
1.Reduced gcm push token day from 7 to 1 days

## [5.3.12] 20% 23-02-2018 100% 24-02-2018 community 100% 28-02-2018
###Fixed
1.FABRIC FIXes -  chat issue

## [5.3.11] 10% 22-02-2018
###Added
1.Showing 'My Matches' as a carousel in the Recent Chats
###Removed
1.Removal of juspay -(we have used the only browser of juspay)
2.Removal of flurry - (flurry was used for event tracking and was not used by anyone)
###Added
1.Added heading Shaadi Chats under conversation tab.
2.Profile Matches Old code clean up - tech debt
3.Photo upload in the background when a user selects a photo from facebook or take a camera picture.

## [5.3.10] 20% 16-02-2018 100% 17-02-2018
###Changes
1.As an android free user I should not be able to chat with another free user even if conversation history exists	
2.Edit profile logout provision
3.New Notification provision
###Fixed
1.Photo from camera upload fix

## [5.3.9] 20% 09-02-2018 100% 10-02-2018 community app 100% 12-02-2018
###Fixed
1.MyPhoto crash fix on release 5.3.8

## [5.3.8] 20% 08-02-2018
###Changes
1.Photo import from Bottom Sheet 
2.Vip consultant number clickable and its redirection to make call
3.An android user will see an online status of the member on the photo along with basic profile information in the buddy list
4.Online status of the member will be displayed in the recent chat section of the buddy list.
5.Accepted and My Matches" sections in the buddy list 
6.Provision of moving photo upload in background
7.Removal of message option from notificationData

## [5.3.7] 100% 26-01-2018
###Added App store removal build

## [5.3.6] 10% 22-01-2018 50% 23-01-2018 100% 24-01-2018
###Added
1.ViP card changes 
2.Multi-photo import from gallery
3.Inbox new card changes - Only invite
###Fixed
1.Fabric bug fixes - logical check
2.Online Member fabric fixes - logical check
3.kitkat shifted up toast notificationData fix


## [5.3.5] 10% 4-01-2018 20% 8-01-2018 100% 10-01-2018
###Added
1.Payment source tracking 
2.Multi-photo import  from facebook
3.Image compression on all old png image - (Size reduction by 1 MB)

###Changed
1.Snowplow library upgrade and its implementation as per new logic
2.Production issue fix where country code and country was not matching in Number verification page.
3.UXCam gender and membership type tracking
4.UI changes edit dialog the message while sending an interest / accept / reminder
###fixes 
Fabric bug fixes all not able to generate

## [5.3.4] 10% 14-12-2017 50% 15-12-2017
###Fixes
1.Fabric logical bug fixes for 5.3.2

## [5.3.3] 5% 13-12-2017
###Added
1.Premium banner in matches
2.Chat presence - online member MVP revamp.
####Changes
1.Package structuring -(Feature-based)  
2.Search Matches listing -MVP revamp(Phase 1)
3.Android Support library version upgrade from 25.4.0 to 26.1.0
4.Juspay library upgrade from 0.6.7 to 0.6.23.3.1421
5.Accepted Image card size increased to the size of matches listing 
6.Few bug fixes

## [5.3.2] 50% 28-11-2017
###Fixed
1.Fabric bug fixes for release 2.3.1

## [5.3.1] 50% 27-11-2017
###Fixed
1.Fabric bug fixes for release 2.3.1
1.FABRIC 26136
2.FABRIC 26105
3.UXcam

1.New matches
## [5.3.0] 50% 24-11-2017
###Added
1.New matches
2.Near me
### Changed
1.New Navigation - introduction of recently viewed and more matches
2.Removed google now card code
3.Pixel score tracking appsflyer
4.Webp in discover crousel cell
5.Added new Reminder notificationData
6. Csat ui changes and its migration to mvp
7.Android Support library upgrade from 23.4.0 to 25.4.0
8.changes target version from 16 to 21 to support new functionality of android
9.Notification id hardcore removal and its replacement with enum ordinal value
10.Daily recommendation custom title 
11.Webp for search result
12.Webp images in for corousel
###Fixed
1.Gender icon fix for new registration user

## [5.2.6] 90% 23-11-2017 100% 24-11-2017
#Changed	
1.The "Send Interest" button has to change to "Connect Now".
2.The Photo album to have new CTA - "Connect Now".
3.Removal of education and income data from card
4.CTA icon changes on card

## [5.2.5] 20% 24-10-2017
### Added
1. Onboarding matches
### Changed
1.CTA button changes
2.Tooltip on send interest
3.Introduction of swipe

## [5.2.4] 100% 24-10-2017
### Changed
1. Dummy release for CTA analysis

## [5.2.3] 50% 10-10-2017 100% 11-10-2017
### Fixes
1.Fabric fixes for release 5.2.2
2. Fabric crash fixes on Accepted listing for hidden members

## [5.2.2] 40% 09-10-2017
### Added
1. Privacy setting changes on release 5.1.8 reverted from CTA release 5.2.1 to 5.1.8

## [5.2.1] 20% 11-09-2017 70% 13-09-2017  then halted
### Fixes
1. Fabric crash fixes for release 5.2.0

## [5.2.0] 20% 08-09-2017  
### Added
1.CTA project
2.View contact in SOA with https
3.Loading external url on click of layer banner - VIP

## [5.1.8]  100% 07-09-2017
### Added - DUMMY APP for AB with CTA

## [5.1.7]  20% 24-08-2017 100% 26-08-2017
### Added
1. New Native payment page with payment in webview
2. Renew case added for premium member when the expiry is less then 20 days
3. Added offer image on top for payment page one - ganesh chaturthi
### Cancelled For Live
1. Native with webview 
2. ABC for webview, old native and new native

## [5.1.6] 100% on 28-07-2017
### Fixed
1. Http to https for secured url

## [5.1.5] 20% 27-07-2017 100% on 28-07-2017
### Added
1. Discount UI elements added to payment page.
2. Support for Silver as another Product.
### Changes
1. Removal of entire promo-code input layout.

## [5.1.4] 20% 15-07-2017 100% on 17-07-2017
### Fixed
1. Logical fabric crash fix which we were not able to generate locally

## [5.1.3] 20% 13-07-2017
### Added
1 The sound has been changed for bottom nav click, send chat single tick and send a message, notificationData sound kept as it is.
2. Most matches trigger point which was kept at hard coded value 50 is now being controlled from server -for this we have added SOA api
###Changes
1 Removed sound from all places except the above added sound.
2 Make photo & delete Photo SOA
3.Appsee key changes as well as moving its start in oncreate
###Fixed
1. In case of same city name for multiple State, Multiple entries for city was being send in partner preference is being fixed
2. Showing album photo key for webp is being fixed
3. Filtered out issue where opening a profile from filtered out and swipe was not working.

## [5.1.2] 20% 27-06-2017 100% 28-06-2017
### Added
1. WebP - loading and showing of webp

## [5.1.1]  20% 18-06-2017 100% 20-06-2017
### Added
1. Partner preference – suggestion module
2. Match Mail notificationData
3. Appsee 
4. Added Event referrer tracking for Recent Visitor & Match Mail notificationData
5. Webp Upload logic controlled from server
6. Payment Split Page
### Changed
6.SOA replacement for zend api for photo upload

## [5.1.0] 20% 08-06-207 [halted next day] 100% 09-06-2017
### Added
-Shoot self – Partner preference
-Swipe – removal of ignore on swipe (any action which shows on left button) action.
### Changed
-Retrieving data from db for profile I viewed, shortlist, ignored and block member
### Fixed
- Fabric crash null check on error showing dialog which we are not able to generate

## [5.0.8] 20% 01-06-2017
### Added
- Most preferred matches
- Empty case handling for ignore profile discover
- event ref for dashboard/discover see all matches listing unviewed
- event ref for dashboard/discover see all matches listing viewed
- New object added in SOA response other, viewed and intent. 

### Changed
- SOA API for getting refine data
- SOA API for Listing API Profile I viewed
- SOA API for Request API - Cancel, decline, accepting, sent reminder, connect
- Event referrer encoding removal and decoding of entry point as said by Sanket & Vishal
- Unix Timestamp logic building for time at client end- ignored, blocked & viewed 
- Message building as per SOA 
- Added empty check if token empty call again GCM token APIs
- Removed country USA from horoscope table
- Changed current residence logic which now comes from the server for intent API (derived_text-location{ "currentresidence":"Los Angeles, CA, USA"}).

### Fixed
- Surprise me fix
- Profile I viewed next profile not loading
- Shortlist inch to feet fix
- Profile I viewed call for hidden member 
- Filtered out on scroll list getting empty

## [5.0.7] 20% 12-05-2017 100% 15-05-2017
### Fixes
- Fabric fixes for release 5.0.6
- Gcm reciever bundle put fix which we were not able to generate - (moved all recieving GCM push to execute on worker there instead on main thread)

## [5.0.6] 20% 10-05-2017
### Changes
- Performace changes 
   - Loading of data in splash screen 
   - 2 api call  , 1. notificationData/android and track-data is now will being called only once.
- Upgrade to latest GCM implementation

## [5.0.5] 20% 19-04-2017 50% 25-04-2017 95%26-04-2017
### Added
- Short code implementation for error messages
- Facebook event integration
- Discover viewed/Unviewed Module
- opt in/ out notificationData tracking
- Added default landing controlled from server
### Changed
- SOA Api for action api Shortlist/Unshortlist, blocked and ignored
- SOA Api for Listing api Shortlist , blocked and ignored
- SOA api for Request api - photo, photo access and contact
- Payment nortan image change
- Removed old code for sub nav landing (code cleanup)
- Refine image changes (Changes done at coach mark, matches and inbox)
- Refine result text changed to refine in Small letters.
- Search manglik do know case encoding changes
### Fixed
- Fabric Crash fixes - mainly intent crash in myactivity
- Changed Image provided by Sunil for refine
- Myphoto duplicate code cleanup

## [5.0.4] 50% 16-03-2017 100% 17-03-2017 
### Changed
- My photo upload resolution from 600x800 to 1200x1600 as said by Parag
### Fixed
- Fabric Crash fixes - mainly intent crash in myactivity
- Changed Image provided by Sunil for refine

## [5.0.3] 50% 15-03-2017
### Added
- Appsee 
- CTA in push 
- Image in push Notification
### Fixed
- Count update logic on preferred matches and inbox
- Changed recent visitor logic from 15 to 30 days
- Fabric crash fixes
- state of refine fix on adjacent tab
- Kibana log error fix as mailed by sanket

## [5.0.2] 50% 06-03-2017 100% 07-03-2017
### Added
- All Viewed chat message to recent chat from online
### Fixed
- Fabric crash fixes


## [5.0.1] 40% 01-03-2017
### Fixed
- Fabric crash fixes

## [5.0.0] 20% 27-02-2017
### Added
- Bottom Navigation Framework
- Highlighting new invitations
- Entire inbox in SOA
- Pull to Refresh
- Event refrer given by karan for dashboard & discover matches

## [4.8.4] 20% 26-12-2016 50% 27-12-2016
### Added
- Add short_type key to preferred matches is came through mailer
- Family shaadi stoppage
- flurry events

### Changed
- Removed hardcore ordering in search
- Apsflyer Updated key for facebook adset to af_adset_id
- Apsflyer Updated key for campaign to af_c_id
- For search we have changed the order where loading of data will be first and marking will be called next.

### Fixed
- Removed db clear logic in Splashscreen cause instead of 5 20 cached profile is being showed on preffered listing
- Inbox loader issue where on second listing loading loader is not being showed this was happening due to header count not to be accounted in second listing loading.


## [4.8.3] 50% 21-11-2016 100% 22-11-2016
### Fixed
- Chat crash fix for two party pay user 
- fabric fixes for 4.8.2

## [4.8.2] 50% 17-11-2016 
### Fixed
- Fabric crash fixes for release 4.8.1
- Myphoto crash fixes due to mvp implementation hard to generate
- Surprise me crash fix due to ads removal fix
### Changed
- Reverted to old chat code 4.7.8 - which contains listview

## [4.8.1] 50% 08-11-2016
### Fixed
- Xema first time load opening next profile if clicked after 6th profile
- Fabric crash fixes - mainly in chat
- Fabric- Profile detail backpress index crash fix
- Last profile back press fix on all listing
- Swipe text aligned in center
- Payment icon image changes and size fix
- Profile preffered matches 6,7th dublication fix
- Flurry crash fix where on lower device less then kitkat it was causing crash
- Inbox fix for a single profile visible for few sec before showing no result
### Changed
- MyPhoto redesign in MVP pattern
- Updated apsflyer api to send event only once in lifetime for that device
- Removed kitkat check for sending imei in apsflyer
### Added
- Integrate new-relic api and send custom attribute	

 
## [4.8.0] CommunityApp 100% 20-10-2016 
### Added
- Added different flurry key for different community app

## [4.7.9] 50% 13-10-2016 100% 14-10-2016 community app 100% 19-10-2016
### Added
- Tracking of delivered notificationData to app
- Flurry 
### Fixed
- Splash screen left right animation update	
- NumberVerification back landing on daily10	
- Crashlytic Forgot pasword and Operator encoding	
- Verify details in chat window when invitation sent to filtered out member
	
### Changed
- Upgrade library version of smack to 1.5, removing unused code from chat module and api call changes	
- Chat migration from Listview to Recycleview	
- The key name for interest stoppage changed from stop-page_interest to stop_page-interest [Karan raised issue fix]

## [4.7.8] 20% 30-08-2016 100% 02-09-2016
### Added
- Click notificationData tracking
- Ads on App

### Changed
- Snowplow screenname changed
- Removal of Ignored from listings.
- Addition of Top Seller Band if silver is absent and limited offer if silver is present on App
- Putting upgrade banner on top of the listing in accepted listing
- New Rate my app design changes after first CUG meeting

### Fixed
- Android one device os not giving device Id.
- Defalult browser for openng offline payment should open in default webview insted for justpay webview 
- Dublicate profile in case of refine (online happening when refine list have less then 6/7 profile).

## [4.7.7] 20% 03-08-2016 
(app was ready on 02/08 but api was not live)
### Added
- Click notificationData tracking

### Changed
- Snowplow screenname changed

### Fixed
- Myphoto backup image crash fix (FABRIC Myphoto crash)

### Changed
- Snowplow screenname changed
3.Ads on App target to retarget user who tryied to give 4 & 5 but cancled to give on play store pop shown
4.Myphoto backup image crash fix (FABRIC Myphoto crash)

## [4.7.6] 50% 21-07-2016 100% 22-07-2016 [YANKED]
### Fixed
- Profile I view marked for first profile issue fixed

## [4.7.5] 20% 11-07-2016 100% 13-07-2016
### Fixed
- Fabric crash fix

## [4.7.4] 20% 08-07-2016 
### Fixed
- Entire tracking issue fix and testing (evt_ref,evt_loc,entpt)
- Offline to online case message is not delivered fixed (Chat).
- Crash fix for 150+ profile scroll search back to listing fix
- FABRIC +QRMS

### Added
- Appsflyer sending Android Id and IMEI data 
- Green flow number verification (case miss added seema).

## Community [4.7.3] 100% 22-06-2016 
## [4.7.3] 20% 15-06-2016 100% 18-06-2016 
### Fixed
- Preferred matches setting count tTab null check as it was crashing
- Myphotos import from gallery which is on cloud fix
- device id null pointer check
- Chatlist fix mehul
- Inbox count check
- Payment page membership crash fix 

- Adding count of preffered matches on app launch through index api value on sub nav.

## [4.7.2] 20% 14-06-2016 
### Added
- Adding count of preffered matches on app launch through index api value on sub nav.

### Changed
- CSAT disable buttom on button click.
- Made URL HTTPS for login

### Fixed
- QRMS-Landing to reset password mailer if the app is in pause state
- ROHHAN-Removed animation on panel for new invites on inbox panel
- QRMS-Sending device id on registration as its was sending default value (--|--)
- FABRIC-Partner preference crash on null fix
- QRMS-Photo coming goes down on shortlist
- QRMS-Upgrade on 4 position instead of third
- QRMS-Dont know case in dont know option
- QMRS-On Change of PP was showing old cashed data fix
- FABRIC-Division by zero case
- FABRIC-Recent chat app crash 
- FABRIC-getting storage logic for few devices crash fix android.
- CHAT-wifi disabled bug solved 
- QMRS-Payment cursor position changes from last to first
- Google GAID tracking not happening issue resolved (Digital marketing)

## [4.7.1]  01-06-2016 
### Fixed
- QRMS bug fixes
- Inbox redirection to profile on click of read more 
- Spelling mistake mutiple to multiple fix on refine

## [4.7.0] 20% 26-05-2016 
### Changed
- Unified Chat
- Snowplow changes for first api tracking
- Syncing list on back press (Accepted,Deleted,inbox,Sent)

### Fixed
- QRMS bug fixes

## [4.6.9] neglected

## [4.6.8] 20% 09-05-2016 100% 12-05-2016
### Removed
- New relick

### Fixed
- QRMS bug fixes

## [4.6.7] 20% 06-05-2016 
### Added
- Snowlpow
- New relick
- Deeplinking
- touch.shaadi.com was introduced for deeplinking

### Fixed
- QRMS bug fixes


### Changed
- Updated changes for appsflyer event tracking
- Daily recommendation matchmailer handling (back handling - daily_recommendations_matchmail landing to daily rec)

## [4.6.6] 100% 26-04-2016 
### Fixed
- Crashlytic Fixes for release 4.6.5

## [4.6.5] 20% 21-04-2016 
### Changed
- New Payment UI
- New CSAT
- Discover caching

## [4.6.4] 100% 12-04-2016 
### Fixed
- Crashlytic Fixes for release 4.6.3

## [4.6.3] 20% 06-04-2016 
### Added
- Help & Support
- Import photo from Facebook
- Irrelevant misuse - ROG Report Abuse Message.
- Added events for apsflyer tracking

### Changed
- Astro UI revamp. (Material design)
- Tracking of internal ratings in app.
- Appsflyer new sdk integration

## [4.6.2] 
### Added
- Adding next profiles on each profile page. (On Hold)
- Astro/Family Gamification.
- Integrate Native Photo Upload and Family Details for ROG Users. 
- Show Family detail based on condition for all users which comes from server.
- Discover
- Sounds in Push Notifications. (On Hold)"

### Changed
- Inbox CTA Animation Improvement 
- Accepted redirection to profile as per ankit changes

### Fixed
- Crashlytic bugs 

## [4.6.1] 18-02-2016 
### Fixed
- Crashlytic bugs for release 4.6.1
- Inbox accept fix

## [4.6.0] 20% 16-02-2016 
### Fixed
- Crashlytic bugs 

### Added
- Daily recommendation last profile swipe
- Sound updation part 2
- Applaunch

### Removed
- appsy 

## [4.5.9] 08-02-2016 
### Fixed
- Crashlytic bugs 

## [4.5.8] 08-02-2016 
### Fixed
- Crashlytic bugs for 4.5.7

## [4.5.7] 20% 04-02-2016 
### Added
- Discover
- Family fields post registration
- Native ROG & Invalid Email ROG rule changes
- CTA
- Push Notification Cycle
- Integrating Sounds
- Added brazil to allow 11 digit phone number varification

### Changed
- Min Daily Reco to 2 per day
- App Start-up Improvement for Android
- Improvement in Daily Recommendation
- Inbox Changes for Performance improvement

## [4.5.6] 19-01-2016 
### Fixed
- Crashlytic fixes for release 4.5.5
- Search fix
- Display Membership color change for premium member
- QRMs bug fixes

## [4.5.5] 20% 15-01-2016 
### Added
- PP and contact filter
- Hide and delete
- Display MembershipImage changes
- Added URL key and its handling to open browser in external browser

## Community [4.5.2] 100% 30-12-2015 
### Fixed
- Image changes

## [4.5.2] 100% 24-12-2015 
### Fixed
- Chat delivery status fix
- Padding on textual chat

## [4.5.1] 
### Changed
- Notification scroll down fix
- Juspay integration

## [4.5.0] 
### Changed
- new chat xmpp
- Search fix

## [4.4.9] 
### Changed
- Reverted old chat

## [4.4.8] 
### Fixed
- Crashlytic fixes of 4.4.7 20%
- Added c "campaign" for appsflyer is af_siteid is null
- Default app launch notificationData

## [4.4.7] 
### Fixed
- Crashlytic fixes of 4.4.7 20%

## [4.4.6] 20%
### Changed
- Retrofit introduction for web api handling
- Stoppage framework
- Rate my App

### Fixed
- Crashlytic

## [4.4.5] 
### Fixed
- Crashlytic

## [4.4.4] 
### Removed
- Uninstall.io

## [4.4.3] 
### Fixed
- Crashlytic fixes of release 4.4.2

## [4.4.2] 
### Added
- Material design
- drip feeding
- undo tracking
- Facebook trust badge

## [4.4.1]  
### Added
- Undo

## [4.4.0] 18-06-2015 
### Added
- spot light/bold listing
- accepted stoppage
- accepted tab
- photo/manglik filter and Shortlist
- Request and Email Mailers Deeplink 
- Force Update

### Changed
- updates uninstall.io jar
- payment exit prompt removed
- updated count value of success stories


## [4.3.7]mobango 18-06-2015 
### Changed
- Mobango release

## [4.3.7]  17-06-2015 
### Fixed
- Payment bug fixes

## [4.3.6]   15-06-2015 
### Fixed
- Crashlytic bug fixes

## [4.3.5] 20%  12-06-2015 
### Changed
- nishant track id changes
- replaced sqlite with ios database
- apsflyer url changes/fixes
- new payment

### Added
- horoscope,
- photo/password request
- retention

### Fixes
- bug fixes

## [4.3.4] 
### Changed
- appsflyer  changes,

## [4.3.3] 25-05-2015
### Changed
- appsflyer  changes,
- deeplinking release

## [4.3.2]
### Added
- appsflyer  changes,
- deeplinking 

## [4.3.1] 20-05-2015 
### Added
- appsflyer changes,
- deeplinking 

## [4.3.0] 
### Added
- setting phone varification
- contact scraping
- uninstall.io 

## [4.2.9] 30-04-2015
### Changed
- http://qrms.peoplelabs.com:3007/release/2715

## [4.2.8]
### Fixed
- Bug fixes 

## [4.2.7]
### Fixed
- QRMS bug fixes id (7614,7807,7806,7690,7295-invalid,7696,7530)
- Crashlytic fixes id (5224)

## [4.2.6] - 14-04-2015 
### Added
- Added gatrack (Fields.customDimension(8),"app-android") as per nishant requirement for tracking
- Call and send sms

### Fixed
- 3492 - Image pinch and tap zoom
- Image upload actual data upload status 
- 6677 QRMS Fixed in this branch
- 7112 QRMS fixed on live build
- 6597 QRMS already fixed in develop 
- 6659 QRMS working this build might be some issues with api previously
- 4588/4570 QRMS (same) already working
- 5906 working on current live build 
- 5156 working on current live build 
- 6231 unable to regenerate even by deepesh (tester)// can mark fix
- 5156 hideen profile is working 
- 5906 working on current liv build 
- 4636 -- working // blocker
- 5325 -- working // blocker
- 6019 -- unable to generate the bug // blocker
- 5899 -- unable to generate the bug // blocker
- 5796 - added full stop
- 4960 - sent loader backgorund fixed
- http://qrms.peoplelabs.com:3007/release/2569

## [4.2.5] - 01-04-2015 
### Fixed
- Telephone fix (changed to telephony for number of user decreased)
- Profile I view Fixes
- Left panel menu not present if profile seen through blacklisted list

## [4.2.4] - 20-03-2015 
### Added
- Write to us for nri users
- Listings -(ignored, blocked , viewed and recent visitors)
- Phone verification

## [4.2.3] - 17-03-2015 
### Fixed
- Payment page native Crashlytic fixes

## [4.2.2] - 2015-12-03
### Changed
- Payment page native

### Fixed
- Crashlytic fix

## [4.1.7] 
### Fixed
- Crashlytic most of the common bug fixed 
- Inbox crash fix if no user found
- crashes due to card showing on other listing where it should not be shown fixed
- new development layer banner and card layer

## [4.0.5]
### Fixed
- 3195 - bug fixed of highligher

## [4.0.1]
### Fixed
- removed profilecontroller
- 2050 - menu check before cleaning - nullpointer error fix
- 2017 - splashscreen activity null pointer erro fix
- 1995 , 2019 spashscreen activty null pointer error fix
- 2005 - myprofiledata fragment fix nullpointer error
- bug fixed
- 2014- daily10 bug fix
- 2002 - dialog bod not attached to activity fix
- 2006 - onactivityresult daily10 fix
- 2003 - external dir nullpointer error fix
- 2003 -  full screen activity null pointer exception fixed
- chat landing fix
- resolved registration bug
- 1196 registration landing issue resolved - daily 10
- 1992 - issue fixed - null pointer error
- 1850 - null pointer check in setting file resolved
- 1813 -  hide keybord null pointer issue resolved
- 1867 -  navigation chat layout fragment fixes
- 1804 - already fixed in release
- cleaned base fragment
- removed profilecontroller file as it si not used 
- easytracker dublicate initalization removed

## [3.2.0] 
### Fixed
- Replaced all Activity.this with getApplicationContext() 
- User notificationData recieved and at same time user logout and then click on notificationData then they are
  redirected to  splash screen activity (earlier they were redirected to chat)
- In case 2 chat was app was crashing


