package com.yuyakaido.android.cardstackview;

import com.yuyakaido.android.cardstackview.internal.CardStackSmoothScroller;

public interface CardStackListener {
    CardStackListener DEFAULT = new CardStackListener() {
        @Override
        public void onCardDragging(Direction direction, float ratio) {
        }

        @Override
        public void onCardSwiped(Direction direction, int topPosition, CardStackSmoothScroller.ScrollType scrollType) {
        }

        @Override
        public void onCardRewound() {
        }

        @Override
        public void onCardCanceled() {
        }
    };

    void onCardDragging(Direction direction, float ratio);

    void onCardSwiped(Direction direction, int topPosition, CardStackSmoothScroller.ScrollType scrollType);

    void onCardRewound();

    void onCardCanceled();
}
