package com.yuyakaido.android.cardstackview;

public enum StackFrom {
    None,
    Top,
    Bottom,
    Left,
    Right,
}
